import java.util.*;

public class Poker
{
	public static Carddeck deck = new Carddeck();
	public static Hand player = new Hand(deck,0);
	public static Prompt prompt = new Prompt();
	public static Game game = new Game();

	
	public static int i;
	public static int decksize; // hods the user's decksize
	public static int exchangeCards;  // holds the number of cards the user wants to exchange.
	public static int menuErrorProof; // ensures that the user puts in the approriate number from the menu list.
	public static int cardnos; //holds the position of the card the user wants to change
	public static boolean goodInput; //this checks to make sure the user does not put a card position number above 5
	public static boolean wins; //checks if there is any wins for the user
	public static boolean playagain; //self explanatory
	public static double currentfunds; //self explanatory
    public static int times = 0; //the number of times the user plays the game
	
	public static void poker()
	{
		if(times==0)
         {
         		currentfunds = game.funds();
         }
         else
         {
          		currentfunds = game.updatedfunds();
	  	        currentfunds = game.newBet();
         }
         
		for(i=0;i<5;i++)
		{
			player.add();
		}
		System.out.println("Your cards are: ");
		
		decksize = player.sizeOfHand();
		for(i=0;i<decksize;i++)
		{
			player.print(i);
		}
		System.out.println("");
		goodInput = false;
		while(goodInput==false)
		{
		System.out.println("Do you want to exchange any of your cards ?\n1. Yes, 1 card\n2. Yes, 2 cards\n3. Yes, 3 cards\n4. Yes, 4 cards\n5. Yes, 5 cards\n6. None ");
		
		
		
		exchangeCards = prompt.integerInput();
		menuError();
		}
		if(exchangeCards != 6)
		{
		
		for(i=1; i<=exchangeCards; i++)
		{
			goodInput = false;
			while(goodInput==false)
			{
			System.out.println("What is the card number position you want to exchange ?" );
			cardnos = prompt.integerInput();
			cardnos = cardnos - 1;
			arrayOutOfBounds();
			}
			player.setHand(cardnos);
			System.out.println("The card has been exchanged");
					
		}
		
		
		}	
		
		
		wins();
		
	}
	
	public static boolean arrayOutOfBounds()
	{
		
		decksize = player.sizeOfHand();
		decksize = decksize-1;
		goodInput = false;
		
		
		if(decksize>=cardnos && decksize>=0)
		{
			goodInput = true;
		}
		else
		{
			System.out.println("Your card hand is not that large. \nEnter a new number from 1 to 5.");
			goodInput = false;
		}
		return goodInput;
	}
	
	public static boolean menuError()
	{
		menuErrorProof = exchangeCards; 
		if(menuErrorProof<=6 && menuErrorProof>=1)
		{
			goodInput = true;
		}
		else
		{
			goodInput = false;
			System.out.println("This option is not on the list");
		}
		return goodInput;
	}
	
	public static void wins()
	{
		player.sort();
        System.out.println("Your sorted cards are: ");
        decksize = player.sizeOfHand();
		for(i=0;i<decksize;i++)
		{
			player.print(i);
		}
		System.out.println("");
		wins = false;
		while(wins == false)
		{
		
		// Royal flush code
		if((player.pokervalue(0)==1)&&(player.pokervalue(1)==10)&&(player.pokervalue(2)==11)&&(player.pokervalue(3)==12)&&(player.pokervalue(4)==13)&&(player.pokerface(0)==player.pokerface(1)) && (player.pokerface(1)==player.pokerface(2)) && (player.pokerface(2)==player.pokerface(3)) && (player.pokerface(3)==player.pokerface(4)))
		{
			wins = true;
			System.out.println("Wow!!, you have just got a royal flush");
			currentfunds = currentfunds * 10;					
			
		}	
		// Straight flush code	
		else if((player.pokervalue(0)==(player.pokervalue(1)-1)) && (player.pokervalue(1)==(player.pokervalue(2)-1)) && (player.pokervalue(2)==(player.pokervalue(3)-1)) && (player.pokervalue(3)==(player.pokervalue(4)-1)) && (player.pokerface(0)==player.pokerface(1)) && (player.pokerface(1)==player.pokerface(2)) && (player.pokerface(2)==player.pokerface(3)) && (player.pokerface(3)==player.pokerface(4)))
		{
			wins = true;
			System.out.println("Congratulations, you got a Straight flush");
			currentfunds = currentfunds * 5;
		}
		
		// 4 of a kind code
		else if((player.pokervalue(0) == player.pokervalue(1)) && (player.pokervalue(1)==player.pokervalue(2))&&player.pokervalue(2)==player.pokervalue(3) || (player.pokervalue(1) == player.pokervalue(2)) && (player.pokervalue(2)==player.pokervalue(3)&&player.pokervalue(3)==player.pokervalue(4)))
		{
			wins = true;
			System.out.println("Congrats, you have just got a 4 of a kind");
			currentfunds = currentfunds * 4.5;
		}
		
		    // full house code
		else if((player.pokervalue(0)==player.pokervalue(1))&&(player.pokervalue(2)==player.pokervalue(3))&&(player.pokervalue(3)==player.pokervalue(4))||(player.pokervalue(0)==player.pokervalue(1))&&(player.pokervalue(1)==player.pokervalue(2))&&(player.pokervalue(3)==player.pokervalue(4)))
		{
			wins = true;
			System.out.println("You have a full house");
			currentfunds = currentfunds * 4;
		}
		
		// flush code
		else if((player.pokerface(0)==player.pokerface(1)) && (player.pokerface(1)==player.pokerface(2)) && (player.pokerface(2)==player.pokerface(3)) && (player.pokerface(3)==player.pokerface(4)))
		{
			wins = true;
			System.out.println("You have a Flush");
			currentfunds = currentfunds * 3.5;
		}	
		
			//a straight code	
		else if((player.pokervalue(0)==(player.pokervalue(1)-1)) && (player.pokervalue(1)==(player.pokervalue(2)-1)) && (player.pokervalue(2)==(player.pokervalue(3)-1)) && (player.pokervalue(3)==(player.pokervalue(4)-1)) || (player.pokervalue(0)==1)&& (player.pokervalue(1)==(player.pokervalue(2)-1)) && (player.pokervalue(2)==(player.pokervalue(3)-1)) && (player.pokervalue(3)==(player.pokervalue(4)-1)))
			{
				wins = true;
				System.out.println("You have a Straight");
				currentfunds = currentfunds * 3;
			}
			
				//three of a kind code
		else if((player.pokervalue(0)==player.pokervalue(1))&&(player.pokervalue(1)==player.pokervalue(2)) || (player.pokervalue(1)==player.pokervalue(2))&&(player.pokervalue(2)==player.pokervalue(3)) || (player.pokervalue(2)==player.pokervalue(3))&&(player.pokervalue(3)==player.pokervalue(4)))
			{
				wins = true;
				System.out.println("You have 3 of a Kind");
				currentfunds = currentfunds * 2.5;
			}
				//two pair code
		else if ((player.pokervalue(0)==player.pokervalue(1)) && (player.pokervalue(2)==player.pokervalue(3)) || (player.pokervalue(0)==player.pokervalue(1)) && (player.pokervalue(3)==player.pokervalue(4))|| (player.pokervalue(1)==player.pokervalue(2)&&player.pokervalue(3)==player.pokervalue(4)))
			{
				wins = true;
				System.out.println("You have Two Pair");
				currentfunds = currentfunds * 2;
			}

			//a pair code
		else if((player.pokervalue(0)==player.pokervalue(1)) || (player.pokervalue(1)==player.pokervalue(2)) || (player.pokervalue(2)==player.pokervalue(3)) || (player.pokervalue(3)==player.pokervalue(4)))
			{
				wins = true;
				System.out.println("You have a Pair");
				currentfunds = currentfunds * 1.5 ;
			}
			else
			{
				System.out.println("Your cards evaluate to nothing.");
				currentfunds = 0 - currentfunds;
				wins = true;
			}
			
			game.updatefunds(currentfunds);
	}	
	     
  
	}
	
	
	public static void play()
	{
		do
		{
			
		poker();
		player.removeAllElements();
		Game game = new Game();
		playagain = game.play();
		times += 1; 
		}while(playagain==true);
	}
}