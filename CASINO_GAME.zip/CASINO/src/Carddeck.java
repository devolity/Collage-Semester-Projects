import java.util.*;

public class Carddeck
{
	public static Vector carddeck = new Vector(52);
	public static Random randnum = new Random(System.currentTimeMillis());
	public static Card Card;
	
	public static int i;
	

	public static void deckinitialize()
	{
		int decksize = carddeck.size();
		for(i=0;i<=51;i++)
		{
			carddeck.add(new Card(i));
			Card =  ((Card)(carddeck.elementAt(i)));
			
		}
		
		
	     
	}
	public static Card uniqueCard()
	{
 		int index;
 		Card element;
 		index = randnum.nextInt(carddeck.size());		
  		element = ((Card)(carddeck.elementAt(index)));
 		carddeck.removeElementAt(index);
 		return element;
 		
	}
	
	}	
	
