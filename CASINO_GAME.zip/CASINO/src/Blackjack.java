import java.util.*;

public class Blackjack
{
          
          public static int i;  
          private static int decksize; //holds the size of both player and computer decks
          private static int sum; // holds the final sum of the player's hand
          private static int compsum; //holds the final sum of the computer's hand
          private static int temp; //a temporary variable that is added to user's sum
          private static int additiontest;  //a test to determine if the users number is over 21
          private static int compadditiontest; // a test to ensure computer is not over 17
          private static int comptemp; //a temporary variable that is added to computer's sum
          private static boolean sumboolean; //returns true if user's sum is not over 21
          private static boolean compsumboolean; //returns true if compute's sum is not over 21
          private static boolean playagain; //the returns true if user wants to play again
          public static Carddeck deck = new Carddeck(); 
          public static Hand player = new Hand(deck,0);
          public static Hand computer = new  Hand(deck,0); //a new hand
          public static Prompt userprompt = new Prompt(); //prompt class
          public static Game game = new Game(); //the game class
          public static int userchoice; //holds whether users want to perform a hit me or a stand
          public static double currentfunds; //this is self explanatory
          public static int times = 0; //the number of times the users play the game
          
          public static void blackjack()
          {
          	
          	if(times==0)
          	{
          		currentfunds = game.funds();
          	}
          	else
          	{
          		currentfunds = game.updatedfunds();
	  	        currentfunds = game.newBet();
          	}
          	
          computer.add();
          computer.add();
          
          System.out.println(" ");	
         	
          	System.out.print("Your cards are: " );
          	
          player.add();
          player.add();
          decksize = player.sizeOfHand();
          for(i=0;i<decksize;i++)
          {
          		
          		player.print(i);
          	    
          }	
          System.out.println("\n ");
          System.out.print("The computer's visible card is: ");
          computer.print(1);
          System.out.println(" ");
          addplayercards();
          while(sumboolean==true)
          {
          System.out.println("Would you like to\n1. Hit me\n2. Stand");
          userchoice = userprompt.integerInput();
          if(userchoice==1)
          {
          	  
          	  player.add();
          	  System.out.print("Your current cards are: ");
          	  decksize = player.sizeOfHand();
          	  for(i=0;i<decksize; i++)
          	  {
         	  	player.print(i);
          	  }
          	  System.out.println(" ");
          	  addplayercards();
          	  
          }
          else if(userchoice==2)
          {
          	 sumboolean = false;
          }
          else
          {
          	  System.out.println("This choice is not in the list");
          }
          } 
          
          
          addcomputercards();
          	
         while(compsumboolean==true)
         {
         	computer.add();
         	addcomputercards();
         }
          decksize = computer.sizeOfHand();
          System.out.println("The final computer cards were: ");
          for(i=0;i<decksize;i++)
          {
          	
          	computer.print(i);
          }
 	      System.out.println(" ");
         wins();
          
          
          	
         }
          
          public static void wins()
          {
          	System.out.println("The sum of the Computer's card is: "+compsum);
          	if(compsum>sum && compsum<=21)
          	{
          		System.out.println("The computer wins this game");
          		currentfunds = 0 - currentfunds;
          	}
          	else if(compsum<sum && sum<=21)
          	{
          		System.out.println("Congratulations!!!\nYou have just won this round");
          		currentfunds = currentfunds;
          	}
          	else if(sum>21)
          	{
          		System.out.println("You busted, therefore you just lost the game");
          		currentfunds = 0- currentfunds;  
          	}
          	else if(compsum>21 && sum<=21)
          	{
          		System.out.println("You won this round of the game");
          		currentfunds = currentfunds;
          	}
          	else if(sum==compsum && sum<=21 && compsum<=21)
          	{
          		System.out.println ("You tie, therefore the computer wins the game");
          		currentfunds = 0 - currentfunds;
          	}
          	
          	game.updatefunds(currentfunds);
          	
          }
          
          
		public static void addplayercards()
          {
          	
          	decksize = player.sizeOfHand();
          	sum = 0;
          
          for(i=0;i<decksize;i++)
          {
          	  temp = player.getValue(i) ; 
          	  if(temp==1)
          	  {
          	  	additiontest = sum + 11;
          	  	if(additiontest<=21)
          	  	{
          	  		temp = 11;
          	  	}
          	  }
          	  sum = sum + temp;
          }
          System.out.println("The sum of your cards is "+sum);
          if(sum<21)
          {
          	sumboolean = true;
          }
          else
          {
          	sumboolean = false;
          }
          
          }
          
          public static void addcomputercards()
          {
          	 decksize = computer.sizeOfHand();
          	 compsum =0;
          	 for(i=0;i<decksize;i++)
          	 {
          	 	comptemp = computer.getValue(i);
          	 
          	 	 if(comptemp==1)
          	  	{
          	  	compadditiontest = sum + 11;
          	  	if(compadditiontest<=21)
          	  	{
          	  		comptemp = 11;
          	  		
          	  	}
          	  }
          	 	compsum = compsum + comptemp;
          	  }
          	 if(compsum<17)
          	 {
          	 	compsumboolean = true;
          	 }
          	 else
          	 {
          	 	compsumboolean = false;
          	 }
          }
          
          public static void play() //this is called in the casino main
          {
          	System.out.println("B  L  A  C  K    J  A  C  K");
          	do
          	{
          	blackjack();
          	player.removeAllElements();
          	computer.removeAllElements();
          	Game game = new Game();
          	playagain = game.play();
          	times += 1;
          	}while(playagain==true);
          	
         	
          }
          
        
}