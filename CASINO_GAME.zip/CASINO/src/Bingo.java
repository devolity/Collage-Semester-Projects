import java.util.*;



public class Bingo


{

public static int Board[ ][ ] = new int [5] [5]; // Naming two dimensional board. 
public static Vector cards = new Vector (24);  // Naming Vector of 24 items.
public static Random randnum = new Random(System.currentTimeMillis());  // Naming Random number function .
public static Game game = new Game();

public static int times = 0;
public boolean playagain;
public static double currentfunds;

public static void Bingo()
{ 

  		  		
  		
  		 
		Board[2][2] = -1;
	
		int tries = 1;
		boolean win =false;
		while(tries<=10 && win==false)   // Recording the number of tries + wins.
		{
	 	int compnum = uniquerandom();
	 	for (int i=0;i<5;i++)
	 	{
	 		for(int j=0;j<5;j++)
	 		{
	 			if (Board[i][j] == compnum)
	 			{
	 				Board[i][j] = -1;
	 				
	 			}
	 	
	 		
	 		
	 		
	 		}
	 	}
	 	for( int i=0;i<5;i++)
	 		{
	 			if(Board[i][0]==-1&&Board[i][1]==-1&&Board[i][2]==-1&&Board[i][3]==-1&&Board[i][4]== -1)
	 			{
	 				
	 				win = true;	
	 				
	 			}
	 		}
	 	for(int i=0;i<5;i++)
	 		{
	 			if(Board[0][i]==-1&&Board[1][i]==-1&&Board[2][i]==-1&&Board[3][i]==-1&&Board[4][i]==-1)
	 			{
	 				win = true;
	 			}
	 		}
	 	if(Board[0][0]==-1&&Board[1][1]==-1&&Board[2][2]==-1&&Board[3][3]==-1&&Board[4][4]==-1)
	 		{
	 			win = true;
	 		}
	 	if(Board[0][4]==-1&&Board[1][3]==-1&&Board[2][2]==-1&&Board[3][1]==-1&&Board[4][0]==-1)
	 		{
	 			win = true;
	 		}				
	 	System.out.println(" ");
	 	printarray();
	 	if(win == true)
	 	{
	 		System.out.println("Bingo\n Well done. You have just WON!!! \n");
	 		currentfunds = currentfunds; 
	 		game.updatefunds(currentfunds);
	 	}
	 	
	 	tries += 1; // Increases tries by 1.
	 	}
	 	if(win == false)
	 	{
	 		currentfunds = 0-currentfunds;
	 		System.out.println("You did not have a win");
	 		game.updatefunds(currentfunds);
	 	
	 	}
 	}
 	
 	public static void printarray()
 	{
 		
 	
 		int i;
 		int j;
 		for(i=0; i<5;i++)
 		{
 			for (j=0; j<5;j++)
 			{
 				
 				if(Board[i][j]== -1)      // prints X in place of -1
 				{
 					System.out.print(" "+"X"); 
 					System.out.print(" ");  // Makes equal spacing.
 				}
 				else
 				{
 					if(Board[i][j]<10)
 						{
 							System.out.print(" "+Board[i][j]);
 							System.out.print(" ");
 						}
 						else
 						{
 							System.out.print(Board[i][j]);
 							System.out.print(" ");
 						}
 				}
 			}
 			System.out.println("");
 		}
 	}
 	public static int uniquerandom()  // to get a unique random number from vector.
 	{
 		int returnValue;
 		int myNum;
 		myNum= randnum.nextInt(cards.size());
 		returnValue=((Integer)cards.elementAt(myNum)).intValue();
 		cards.removeElementAt(myNum);
 		return returnValue;
 		
 	    
 	}
 	
 	
 	public static void initializearray()  // to initialize the array.
 	{
 	    int i;
 	    int j;
 	    if(times == 0)
  		{
  			currentfunds = game.funds();
  		}
  		else
  		{
  			  currentfunds = game.updatedfunds();
	  	      currentfunds = game.newBet();

  		}

 	     
 	    for(i=0; i<5;i++)
 	    {
 	    	for(j=0;j<5;j++)
 	    	{
 	    	
 	    	
 	    		Board[i][j] = uniquerandom();
 	    		if(Board[i][j]<10)
 	    		{
 	    			System.out.print(" "+Board[i][j]);
 	    			System.out.print(" ");
 	    		}
 	    		else
 	    		{
 	    		System.out.print(Board[i][j]);
 	    		System.out.print(" ");
 	    		}
 	    	}
 	    	System.out.println(" ");
 	    }	
 		
 	}
 	
 	
 	public static void initvector(int numofelements)  // to initialize the vector
 	{
 	
 		cards = new Vector();
 		int i;
 		for (i=0; i<=numofelements;i++)
 		{
 			cards.add(i);
 		    
 		}
 	}
 	public void play()
 	{
 		System.out.println("B  I  N  G  O");
 		do
 		{
 		initvector(24);
	 	initializearray();
	 	initvector(24);
	 	Bingo();
	 	Game game = new Game();
	 	playagain = game.play();
	 	times += 1;
		}while(playagain==true);
 	}
 	
} 	
 	
// End of Bingo Function

