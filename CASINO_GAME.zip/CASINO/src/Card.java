import java.util.*;

public class Card
{
	public  int ID;   // holds the index number of the cards
	private  Carddeck deck;
	public int pokervalue;
	public  int value;  // holds the true value of the cards
	public String face;  // the face of the cards Ace to King
	public String suit;   // the suit of the cards
	public String Faces[ ]  = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"}; //the face value array
	public String Suit[ ]= {"D", "S", "C", "H"}; //the suit array
    public int Value[ ]={1,2,3,4,5,6,7,8,9,10,10,10,10}; //the value of the cards
    public int pokerValue[ ] = {1,2,3,4,5,6,7,8,9,10,11,12,13}; //the special value of poker cards
    
	
	public Card(int newID)
	{
		ID = newID;
		face = Faces[ID%13];
		suit = Suit[(int)(ID/13)];
		value = Value[ID%13];
		pokervalue = pokerValue[ID%13];
	}
	
    public  void print(Card newCard)
	{
		Card myCard;
		myCard = newCard;
	     System.out.print(face + suit+" ");
	    // System.out.print();//first of all get the index number.
	} 	



	 public int cardValue(int newID) //this function is dependent on the face of the card therefore face must be called before it.
	{
	    ID = newID;
	    int test;
	    test = ID%13;
	    value = Value[test];
	    return value;   
	}

	


	
}