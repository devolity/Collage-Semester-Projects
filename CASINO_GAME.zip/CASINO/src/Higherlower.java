import java.util.*;


public class Higherlower 
{
	public Game game = new Game();
	
	private boolean playagain;
	public int x; // this holds the random number
	public int userguess; //holds the guesses of the user
	public double currentfunds;
	public static  int times = 0 ; // this is to make sure the funds does not re initialize
	
	public  void higherlower()
	{ 
	  
	 
	  Random mynum = new Random();
	  x = mynum.nextInt(50); // assigning the random number to x.
	  int right;
	  int counter;
	  right = 0;
	  System.out.println("H   I  G  H  E  R    L  O  W  E  R");
	  
	  if(times == 0)
	  {
	  currentfunds = game.funds();
	  }
	  else
	  {
	  	
	  	currentfunds = game.updatedfunds();
	  	currentfunds = game.newBet();
	  }
	  System.out.println("Note: You have only 5 trials\nThe number chosen by the computer is X\n Enter a number from 1-50");
	  
	  for(counter=0;counter<=4;counter++)
	  {
	  	
	  	System.out.println("");
	  	System.out.println("Please enter your guess");
	  	
	  	Prompt userPrompt = new Prompt();
	  	userguess = userPrompt.integerInput();
	  	
	  	if(userguess==x)
	  	{
	  		System.out.println("You have guessed the right number");
	  		currentfunds = currentfunds ;
	  		game.updatefunds(currentfunds);
	  		counter = 5;
	  	}
	  	
	  	if(userguess>x)
	  	{
	  		System.out.println("Wrong Guess.");
	  		System.out.println("");
	  		System.out.println("Go Lower");
	  	}
	  	
	  	if(userguess<x)
	  	{
	  		System.out.println("Wrong Guess.");
	  		System.out.println("");
	  		System.out.println("Go Higher");
	  	}
	  	
	  	 
	  	
	  }
	  if(userguess!=x)
	  {
	  	currentfunds = 0 - currentfunds;
	  	game.updatefunds(currentfunds);
	  } 
	  
	 	
	}
	
	
	public void play()
	{
	
		do
		{
		higherlower();
		Game game = new Game();
		playagain = game.play();
		times = times +1;
		}while(playagain==true);
		
	}
	
	}

