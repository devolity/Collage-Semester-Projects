/**
 * OKOYE CHUKA DANIEL
 *
 * CASINO GAME IN OBJECT ORIENTED PROGRAMMING STYLE
 *
 *4TH OF JANUARY 2006
 *
 *VERSION 2.1.1
 *
 */
 import java.util.*;
 
public class CASINO 
 {
 
  	
    public static void main (String[] args)
    {
    Integer gameoption; //holds the user's choice of games
	gameoption=0;
	
	
	while(gameoption != 6)
    
    {  
    
  
	System.out.println(" Welcome to Hello World ASCII Casino\n\n A Casino of Hope and Possiblities\n\n Choose from the menu below to start a game\n  1.  Poker\n  2.  Black Jack\n  3.  Roulette\n  4.  Bingo\n  5.  Higher Lower\n  6.  Quit" );
	
	
	
	
	
	Prompt userPrompt = new Prompt();
	gameoption = userPrompt.integerInput();
	
	if (gameoption==1) // Begin Poker
	{
	Poker pokerGame = new Poker();
	pokerGame.play();	
	System.out.println("Thank you for playing Poker\n");
	} // End Poker
		
	 if (gameoption==2) // Begin BlackJack
	 {
	 
	 	Blackjack blackjackGame = new Blackjack();
	 	blackjackGame.play();
	 	System.out.println("Thank you for playing Black Jack\n");
	 }// End BlackJack
	 if (gameoption==3) // Begin Roulette
	 {
	 	  Roulette rouletteGame = new Roulette();
	    rouletteGame.play();
	    System.out.println("Thank you for playing Roulette\n");
	 }//end Roulette
	 
	if (gameoption==4) // Begin Bingo
	{
		Bingo bingoGame = new Bingo();
		bingoGame.play();
		System.out.println("Thank you for playing Bingo\n");
	}// end Bingo
	
	if (gameoption==5) // begin Higher Lower
	{
		Higherlower hiLoGame = new Higherlower();
		hiLoGame.play();
		System.out.println("Thank you for playing Higher Lower\n");
	}//end higher lower
	
    		
	}
	System.out.println("Thank you for playing Hello World Casino.\nBye");
    }
    
}
