import java.util.*;

public class Hand
{
	public Carddeck deck; //all it says is u are expecting a variable of type carddeck.
	public  Card card;
	public int i;
	public int j; 
	public int handSize; //holds the size of the vector player vector
	public int decksize; //holds the size of the vector also
	public int myCard; //holds cards got from the card deck
	public Card temp; //a temporary variable for cards
	
	public Vector cardHand = new Vector();
	public  Hand(Carddeck newdeck,int numberOfCards) //for the intial issuance of cards to both players.the newdeck just points to the same vector called deck.
	{
		deck.deckinitialize();
		deck = newdeck; 
		for(i=0;i<numberOfCards;i++)
		{
			cardHand.add(deck.uniqueCard());
		}
		
		
	}
	
	public void add()//for the hit me
	{
		
		cardHand.add(deck.uniqueCard());
	}
	public  void print(int newID)
	{
		int myCard;
		myCard = newID;
	     card = ((Card)(cardHand.elementAt(myCard)));
	     card.print(card);
	 
	} 
	
	public int sizeOfHand()
	{
		handSize = cardHand.size();
		return handSize;
	}

	
	public int getValue(int positionOfCard) // this is wrong bcos u have to search for the card that matches the user own in the orginal deck then submit the value.
	{
		int cardIndex;
		int cardID;
		int cardValue;
	    Card cardProp;
		cardIndex = positionOfCard;
		cardProp = ((Card)(cardHand.elementAt(cardIndex)));
		cardID = cardProp.ID;
		card = cardProp;
		cardValue=card.value; //giving the cardValue function in card the id to get value of card.
		return cardValue;
		
	}
	
	public void removeAllElements()
	{
		cardHand.clear();
	}
	
	public void setHand(int newposition)
	{
		int cardIndex;
		cardIndex = newposition;
		temp = deck.uniqueCard();
		cardHand.set(cardIndex, temp);
		
	}
	
   public void sort()
   {
   	decksize = cardHand.size();
		for(j=decksize -1 ; j>=0; j--)
		{
			for( i=0; i<j;i++)
			{
				
				int value1;
				int value2;
				Card temp = (Card)cardHand.elementAt(i);
				card = temp;
				value1 = card.pokervalue;
				temp = (Card)cardHand.elementAt(i+1);
				card = temp;
				value2 = card.pokervalue;
				if(value1 > value2)
				{
					
					temp = (Card)(cardHand.elementAt(i));
					cardHand.set(i, (Card)cardHand.elementAt(i+1));
					cardHand.set(i+1,temp);
				}
			}
		}
   }
   
   public int pokervalue(int positionOfCard)
   {
   		int cardIndex;
		int cardID;
		int cardValue;
	    Card cardProp;
		cardIndex = positionOfCard;
		cardProp = ((Card)(cardHand.elementAt(cardIndex)));
		cardID = cardProp.ID;
		card = cardProp;
		cardValue=card.pokervalue; //giving the cardValue function in card the id to get value of card.
		return cardValue;
   }	
	
	public String pokerface(int positionOfCard)
	{
		int cardIndex;
		String cardface;
	    Card cardProp;
		cardIndex = positionOfCard;
		cardProp = ((Card)(cardHand.elementAt(cardIndex)));
		card = cardProp;
		cardface =card.face; //giving the cardValue function in card the id to get value of card.
		return cardface;
	}
	

}