import java.util.*;
public class Roulette
{
	public static Random randnum = new Random(System.currentTimeMillis());
	public static Game game = new Game();
	
	public static int betChoice; // holds the number users choose during bets.
	public static String numtype; // holds wether number is even or odd.
	public static int numberCode; // test condition for number bets
	public static int evenOddCode; // test condition for even odd bets
	public static boolean playagain; // the play again boolean.
	public static int times = 0;
	public static double currentfunds;
	
	
	
	public static void roulettegame()
	{
		
	    if(times == 0)
	    {
	    	currentfunds = game.funds();
	    	
	    }
	    else
	    {
	    	currentfunds = game.updatedfunds();
	  		currentfunds = game.newBet();
	    }
	    int menuChoice;	
		System.out.println("Choose From the Options Below to place a Bet or Roll Wheel");
		System.out.println("1. Number\n2. Even or Odd");
		System.out.println("3. Roll Wheel. ");
		
		/* menuChoice1 = number
		 * menuChoice2 = Even or Odd
		 * menuChoice3 = RollWheel
		 */
		
		int goodInput = 1;
		while(goodInput== 1)
		{
		Prompt userPrompt = new Prompt(); //the prompt class
		
		menuChoice = userPrompt.integerInput();  
		if (menuChoice==1)
		{
			numberCode = 1; // makes the computer do a comparison
			numberChoice1();
			System.out.println("Choose From the Options above to place a Bet or Roll Wheel");
		}
		if (menuChoice==2)
		{
			evenOddCode = 1;
			numberChoice2();
			System.out.println("Choose From the Options above to place a Bet or Roll Wheel");
		} 
		
		if(menuChoice==3)
		{
			numberChoice3();
			goodInput = 0;
			
		}
		
		
		
		
		}// end of while loop.
	}
	
	public static void numberChoice1()    //to place a bet on a number
	{
		System.out.println("Please choose a number between 0 and 28 to place bet on");
		int loop=0;
		while(loop!=1) 
		{
			Prompt userPrompt = new Prompt();
			betChoice= userPrompt.integerInput();
			if (betChoice<29 && betChoice>=0)
			{
			System.out.println("Your bet is currently placed on " + betChoice);
			loop = 1;
			}
			else
			{
			System.out.println("This number is not in the range specified");
			System.out.println("Enter a new number to place bet on");
			}
			
			
		
		} // end of while loop.
	}  //place bet on number
	
		
	
	public static void numberChoice2()   //to place a bet on number type(even or odd)
	{
	
		int overtest = 0;
		while(overtest !=1 )
		{
		System.out.println("Choose which number type to place bet on\n1. Even\n2. Odd");
		int number;
		
		Prompt userPrompt = new Prompt();	
		number = userPrompt.integerInput();
		int test = 0;
		while (test !=1) // prevents the player from selecting a wrong number not on the list.
		{
		
		if(number == 1)
		{	
			System.out.println("You placed your bet on an even number");
			test =1;
			overtest =1;
			numtype="even";
		}
		if(number==2)
		{
			System.out.println("You place your bet on an odd number");
			test =1;
			overtest = 1;
			numtype="odd";
		}
		 if(number!=1&&number!=2)
		{
			System.out.println("You did not choose a number type sucker");
			test =1;
		}
		}
		
	
		} // end of first while loop
	} //end of place bet on even or odd function
	
	 
	public static void numberChoice3() //for the user to spin the wheel   
	{
		
		int wheelnum = randnum.nextInt(28);// spins the wheel.
		int test;
		test = wheelnum%2;
		
	/*the following code below is to evaluate all the possible win conditions*/
	
		if(test==0)// beginning of even mod
		{
		if(numtype=="even") // converting numtype to a number for program to evaluate.
		{
			System.out.println("The ball stopped at " +wheelnum);
			System.out.println("Your even number guess was right");
			currentfunds = currentfunds;
			
			
		}
		if(numtype=="odd")
		{
			System.out.println("The ball stopped at " +wheelnum);
			System.out.println("Your odd number guess was wrong");
			currentfunds = 0 - currentfunds;
			
		}
		
		}// end even mod
		if(test==1) // beginning of odd mod
		{
			if(numtype=="odd")
				{
			     	System.out.println("The ball stopped at " +wheelnum);
			     	System.out.println("Your odd number guess was right");  
			     	currentfunds = currentfunds;
			     	
				}
			if(numtype=="even")
			{
				System.out.println("The ball stopped at " +wheelnum);
				System.out.println("You even number guess was wrong");
				currentfunds = 0 - currentfunds;
				
			}
		} // end of odd mod.
		
		if(numberCode==1 && betChoice==wheelnum)
		{
			System.out.println("The ball stopped at " +wheelnum);
			System.out.println("Its your lucky day.\n\n You have just won the game");
			currentfunds = currentfunds * 1.5;
			
		}
		if(numberCode==1 && betChoice!=wheelnum)
		{
			System.out.println("The ball stopped at " +wheelnum);
			System.out.println("Hey, you placed your bet on the wrong number, loser.");
			currentfunds = 0- currentfunds;
			
		}
		if(evenOddCode!= 1 && numberCode!= 1)
		{
			System.out.println("Scared of placing bets ?\nYou chose to roll the wheel without placing any bets.\nThe ball stopped at "+wheelnum);
			currentfunds = 0;
		}
		
		
			currentfunds = currentfunds;
		
		
		game.updatefunds(currentfunds);
		

	} //roll wheel.
	
	public static void play()  //this function is called from the casino main.
	{
		System.out.println("R  O  U  L  E  T  T  E");
		do
		{
		roulettegame();
		numtype = "";
		betChoice = 0;
		Game game = new Game();
		playagain = game.play();
		times = times +1;
		}while(playagain==true);
	}
	
	
}