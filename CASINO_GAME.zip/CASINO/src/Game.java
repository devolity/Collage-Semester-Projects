import java.util.*;

public class Game 
{
	public  boolean playagain; //the play again boolean
	public static boolean goodbet; //makes sure user does not enter a number greater than the amount available for bet
	public  int gameoption; //holds wether user wants to play again or not
	public int wrongnumber = 1;//prevents the user from entering the wrong number not on the list.
	public static double Funds; //holds the users money
	public static double betamount;
	public static double returnedfunds;//the amount returned from the games
	public  boolean play()
	{
   		while(wrongnumber==1)
   		{
		System.out.println("Would you like to play again\n 1. Yes\n 2. No ");
		Prompt userPrompt = new Prompt();
		gameoption = userPrompt.integerInput();
		if(gameoption==1)
		{
			playagain=true;
			wrongnumber = 0;	
			
		}
		else if(gameoption==2)
		{
			playagain=false;
			wrongnumber = 0;
		}
		}
		return playagain;
	}
	
	public static double funds()
	{
		Funds = 10000;
		System.out.println("You have $" +Funds);
		System.out.println("How much would you like to bet: ");
		Prompt userPrompt = new Prompt();
		
		goodbet = true;
		
		while(goodbet == true)
		{
			System.out.print("$");
		
		
			betamount = userPrompt.integerInput();
		if(betamount<=Funds && betamount>0)
		{
			System.out.println("You have chosen to bet $" + betamount);
			goodbet = false;
		
		}
		else if(betamount>Funds || betamount<0)
		{
			System.out.println("You dont have this amount of money. Enter a new bet");
			goodbet = true;
		
		}
		
		
		}
		System.out.println("You do not have any more money to bet");
		return betamount;
		
	}
	
	public static void updatefunds(double newfunds)
	{
	    returnedfunds = newfunds;
	    
		Funds = Funds + returnedfunds;
		
		System.out.println("You current funds is now $" +Funds);
		if(Funds<=0)
		{
			System.out.println("You have run out of funds.\nThank you for playing Hello World Casino.\nBye");
			System.exit(0);
		}
	}
	
	public static double updatedfunds()
	{
		return Funds;
	}
	
	public static double newBet() // this is for the user to place a new bet after the first one
	{
		
		
	System.out.println("You have $" +Funds);
		System.out.println("How much would you like to bet: ");
		Prompt userPrompt = new Prompt();
		
		goodbet = true;
		
		while(goodbet == true)
		{
			System.out.print("$");
		
		
			betamount = userPrompt.integerInput();
		if(betamount<=Funds && betamount>0)
		{
			System.out.println("You have chosen to bet $" + betamount);
			goodbet = false;
		
		}
		else if(betamount>Funds && Funds>0)
		{
			System.out.println("You dont have this amount of money. Enter a new bet");
			goodbet = true;
		
		}
		
		else
		{
			System.out.println("You do not have any more money to bet");
			goodbet = false;
		}
		
		}
		

		return betamount;
		
	}
	}