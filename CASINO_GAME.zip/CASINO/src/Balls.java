import java.util.*;

public class Balls
{
	public static Random randnum = new Random(System.currentTimeMillis());
	public static Vector bingoballs = new Vector(25);
	private static int i;
	private static int bingoNumber;
	private static int mynum;
	private static int sizeOfVector;
	public static void initializeBingoVector()
	{
		for(i=0;i<=24;i++)
		{
			bingoballs.add(i);
		}
	}
	
	public static int uniqueBingoNumber()
	{
		sizeOfVector = bingoballs.size();
		mynum = randnum.nextInt(sizeOfVector);
		bingoNumber = ((Integer)bingoballs.elementAt(mynum)).intValue();
		bingoballs.removeElementAt(mynum);
		return bingoNumber;
	}
	
}