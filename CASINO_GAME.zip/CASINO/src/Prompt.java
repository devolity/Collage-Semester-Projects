import java.util.*;


public class Prompt
{
	public static Scanner input = new Scanner(System.in);
	public static boolean exit;
	public static int gameoption;
	public static int integerInput()
	{
	
		exit = false;
		
		while(exit!=true)
		{
		if(input.hasNextInt())
		{
		gameoption = input.nextInt();
		exit = true;
		input = new Scanner(System.in);
	    
		}
		else
		{
			System.out.println("Please put in a valid Integer");
			input = new Scanner(System.in);
		}
		}
		return gameoption;
	}
	
}