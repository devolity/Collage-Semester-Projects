using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Powerball_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void getPowerballNumbers()
        {
            System.Net.WebClient WC = new System.Net.WebClient();
            string httploc = "http://www.powerball.com/powerball/pb_numbers.asp";
            string[] tempArray = new System.IO.StreamReader(WC.OpenRead(httploc)).ReadToEnd().Split(Convert.ToChar("\n"));
            string s = "";
            int counter = 0;
            for (int i = 0; i < tempArray.Length; i++)
            {
                if (tempArray[i].IndexOf("<td background=\"/images/ball_white_40.gif\" width=\"39\" height=\"40\"><b><font size=\"5\">") != -1)
                {
                    if (counter == 0)
                    {
                       counter++;
                       lblWb1.Text = tempArray[i].Replace("<td background=\"/images/ball_white_40.gif\" width=\"39\" height=\"40\"><b><font size=\"5\">", "").Replace("</font></b></td>", "").Trim();
                       lblDd.Text = tempArray[i - 1].Replace("<td><b>", "").Replace("</font></b></td>", "").Trim();
                   }
                    else if (counter == 1)
                    {
                        counter++;
                        lblWb2.Text = tempArray[i].Replace("<td background=\"/images/ball_white_40.gif\" width=\"39\" height=\"40\"><b><font size=\"5\">", "").Replace("</font></b></td>", "").Trim();
                    }
                    else if (counter == 2)
                    {
                        counter++;
                        lblWb3.Text = tempArray[i].Replace("<td background=\"/images/ball_white_40.gif\" width=\"39\" height=\"40\"><b><font size=\"5\">", "").Replace("</font></b></td>", "").Trim();
                    }
                    else if (counter == 3)
                    {
                       counter++;
                       lblWb4.Text = tempArray[i].Replace("<td background=\"/images/ball_white_40.gif\" width=\"39\" height=\"40\"><b><font size=\"5\">", "").Replace("</font></b></td>", "").Trim();
                    }
                    else if (counter == 4)
                    {
                       counter++;
                       lblWb5.Text = tempArray[i].Replace("<td background=\"/images/ball_white_40.gif\" width=\"39\" height=\"40\"><b><font size=\"5\">", "").Replace("</font></b></td>", "").Trim();
                    }

                }
                if (tempArray[i].IndexOf("<td background=\"/images/ball_red_40.gif\" width=\"39\" height=\"40\"><b><font size=\"5\">") != -1)
                {
                    if (counter == 5)
                    {
                        counter++;
                        lblPb.Text = tempArray[i].Replace("<td background=\"/images/ball_red_40.gif\" width=\"39\" height=\"40\"><b><font size=\"5\">", "").Replace("</font></b></td>", "").Trim();
                    }
                }
                if (tempArray[i].IndexOf("&nbsp;&nbsp;</font></b>") != -1)
                {
                    if (counter == 6)
                    {
                        counter++;
                        lblPp.Text = "x " + tempArray[i].Replace("&nbsp;&nbsp;</font></b>", "").Trim();
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            getPowerballNumbers();
        }
    }
}