namespace Powerball_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblDd = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblPp = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblWb3 = new System.Windows.Forms.Label();
            this.lblPb = new System.Windows.Forms.Label();
            this.lblWb5 = new System.Windows.Forms.Label();
            this.lblWb4 = new System.Windows.Forms.Label();
            this.lblWb2 = new System.Windows.Forms.Label();
            this.lblWb1 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.lblDd);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.lblPp);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.lblWb3);
            this.groupBox2.Controls.Add(this.lblPb);
            this.groupBox2.Controls.Add(this.lblWb5);
            this.groupBox2.Controls.Add(this.lblWb4);
            this.groupBox2.Controls.Add(this.lblWb2);
            this.groupBox2.Controls.Add(this.lblWb1);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(415, 134);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Powerball Numbers";
            // 
            // lblDd
            // 
            this.lblDd.AutoSize = true;
            this.lblDd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDd.Location = new System.Drawing.Point(6, 56);
            this.lblDd.Name = "lblDd";
            this.lblDd.Size = new System.Drawing.Size(0, 17);
            this.lblDd.TabIndex = 30;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Blue;
            this.label15.Location = new System.Drawing.Point(6, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 17);
            this.label15.TabIndex = 29;
            this.label15.Text = "Draw Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(324, 26);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 17);
            this.label14.TabIndex = 28;
            this.label14.Text = "Powerball";
            // 
            // lblPp
            // 
            this.lblPp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPp.ForeColor = System.Drawing.Color.Blue;
            this.lblPp.Location = new System.Drawing.Point(341, 92);
            this.lblPp.Name = "lblPp";
            this.lblPp.Size = new System.Drawing.Size(39, 25);
            this.lblPp.TabIndex = 27;
            this.lblPp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(243, 100);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(92, 13);
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // lblWb3
            // 
            this.lblWb3.BackColor = System.Drawing.Color.Transparent;
            this.lblWb3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWb3.Image = ((System.Drawing.Image)(resources.GetObject("lblWb3.Image")));
            this.lblWb3.Location = new System.Drawing.Point(186, 43);
            this.lblWb3.Name = "lblWb3";
            this.lblWb3.Size = new System.Drawing.Size(39, 40);
            this.lblWb3.TabIndex = 23;
            this.lblWb3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPb
            // 
            this.lblPb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPb.Image = ((System.Drawing.Image)(resources.GetObject("lblPb.Image")));
            this.lblPb.Location = new System.Drawing.Point(341, 43);
            this.lblPb.Name = "lblPb";
            this.lblPb.Size = new System.Drawing.Size(39, 40);
            this.lblPb.TabIndex = 26;
            this.lblPb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWb5
            // 
            this.lblWb5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWb5.Image = ((System.Drawing.Image)(resources.GetObject("lblWb5.Image")));
            this.lblWb5.Location = new System.Drawing.Point(275, 43);
            this.lblWb5.Name = "lblWb5";
            this.lblWb5.Size = new System.Drawing.Size(39, 40);
            this.lblWb5.TabIndex = 25;
            this.lblWb5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWb4
            // 
            this.lblWb4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWb4.Image = ((System.Drawing.Image)(resources.GetObject("lblWb4.Image")));
            this.lblWb4.Location = new System.Drawing.Point(230, 43);
            this.lblWb4.Name = "lblWb4";
            this.lblWb4.Size = new System.Drawing.Size(39, 40);
            this.lblWb4.TabIndex = 24;
            this.lblWb4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWb2
            // 
            this.lblWb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWb2.Image = ((System.Drawing.Image)(resources.GetObject("lblWb2.Image")));
            this.lblWb2.Location = new System.Drawing.Point(141, 43);
            this.lblWb2.Name = "lblWb2";
            this.lblWb2.Size = new System.Drawing.Size(39, 40);
            this.lblWb2.TabIndex = 22;
            this.lblWb2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWb1
            // 
            this.lblWb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWb1.Image = ((System.Drawing.Image)(resources.GetObject("lblWb1.Image")));
            this.lblWb1.Location = new System.Drawing.Point(96, 43);
            this.lblWb1.Name = "lblWb1";
            this.lblWb1.Size = new System.Drawing.Size(39, 40);
            this.lblWb1.TabIndex = 21;
            this.lblWb1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(441, 159);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form1";
            this.Text = "Powerball Project";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblPb;
        private System.Windows.Forms.Label lblWb5;
        private System.Windows.Forms.Label lblWb4;
        private System.Windows.Forms.Label lblWb2;
        private System.Windows.Forms.Label lblWb1;
        private System.Windows.Forms.Label lblWb3;
        private System.Windows.Forms.Label lblPp;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblDd;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
    }
}

