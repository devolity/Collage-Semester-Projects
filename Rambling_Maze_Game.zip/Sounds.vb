Module Sounds
    Private Files() As String = New String() _
                           {"..\sound\cash.wav", _
                            "..\sound\fueling.wav", _
                            "..\sound\gold.wav", _
                            "..\sound\van.wav", _
                            "..\sound\newmap.wav", _
                            "..\sound\gameover.wav", _
                            "..\sound\stash.wav", _
                            "..\sound\farsiren.wav", _
                            "..\sound\nearsiren.wav", _
                            "..\sound\caught.wav", _
                            "..\sound\ramblin.mid"}

    ' Provides better inline documentation (self desc.)
    Public Enum LocalFile
        Cash
        Fueling
        Gold
        Van
        NewMap
        GameOver
        Stash
        FarSiren
        NearSiren
        Crash
        Ramblin
    End Enum

    Private QuickSound As Org.Mentalis.Multimedia.SoundFile
    Private SongSound As Org.Mentalis.Multimedia.SoundFile
    Private SirenSound As Org.Mentalis.Multimedia.SoundFile

    Private OldSong As String
    Private OldSound As String
    Private OldSiren As String

    Public Sub PlaySound(ByVal Sound As LocalFile)
        If OldSound <> Files(Sound) Then
         If Not QuickSound Is Nothing Then
            If QuickSound.Status = Org.Mentalis.Multimedia.StatusInfo.Playing Then QuickSound.StopPlay()
            QuickSound.Dispose()
         End If
         QuickSound = New Org.Mentalis.Multimedia.SoundFile(Files(Sound))
         OldSound = Files(Sound)
      End If
        If Sound = LocalFile.Fueling Then QuickSound.Repeat = True
        QuickSound.Play()
    End Sub

    Public Sub PlaySong(ByVal Playback As Boolean)
        If OldSong <> Files(LocalFile.Ramblin) Then
            SongSound = New Org.Mentalis.Multimedia.SoundFile(Files(LocalFile.Ramblin))
            OldSong = Files(LocalFile.Ramblin)
        End If
        If Playback Then
            SongSound.Play()
        Else
            If SongSound.Status = Org.Mentalis.Multimedia.StatusInfo.Playing Then SongSound.StopPlay()
        End If
    End Sub

    Public Sub PlaySiren(ByVal Playback As Boolean)
        If OldSiren <> Files(LocalFile.NearSiren) Then
            SirenSound = New Org.Mentalis.Multimedia.SoundFile(Files(LocalFile.NearSiren))
            OldSiren = Files(LocalFile.NearSiren)
        End If
        If Playback Then
            SirenSound.Repeat = True
            SirenSound.Play()
        Else
            SirenSound.Repeat = False
            If SirenSound.Status = Org.Mentalis.Multimedia.StatusInfo.Playing Then SirenSound.StopPlay()
        End If
    End Sub

    Public Sub SirenVolume(ByVal Volume As Integer)
        If Not SirenSound Is Nothing Then SirenSound.Volume = Volume
    End Sub


    Public Sub CloseSounds()
        If Not QuickSound Is Nothing Then
            If QuickSound.Status = Org.Mentalis.Multimedia.StatusInfo.Playing Then QuickSound.StopPlay()
            QuickSound.Dispose()
        End If
        If Not SongSound Is Nothing Then
            If SongSound.Status = Org.Mentalis.Multimedia.StatusInfo.Playing Then SongSound.StopPlay()
            SongSound.Dispose()
        End If
        If Not SirenSound Is Nothing Then
            If SirenSound.Status = Org.Mentalis.Multimedia.StatusInfo.Playing Then SirenSound.StopPlay()
            SirenSound.Dispose()
        End If
        OldSound = ""
        OldSiren = ""
        OldSong = ""
    End Sub
End Module
