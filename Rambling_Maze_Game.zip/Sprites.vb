Imports Rambling.GameCode



Friend Class Sprite
    Private myArtWork(4) As Bitmap
    Private myDirection As TravelDirection
    Private myCenter As Point
    Private myLocation As Point
    Private mySpeed As Integer
    Public Color As Color


    Public Sub New()
        '
    End Sub

    Public Sub New(ByVal Location As Point)
        Me.Location = Location
    End Sub

    Friend Property Direction() As TravelDirection
        Get
            Return myDirection
        End Get
        Set(ByVal Value As TravelDirection)
            myDirection = Value
        End Set
    End Property

    Friend Property Speed() As Integer
        Get
            Return mySpeed
        End Get
        Set(ByVal Value As Integer)
            mySpeed = Math.Abs(Value)
        End Set
    End Property

    Friend Property Location() As Point
        Get
            Return myLocation
        End Get
        Set(ByVal Value As Point)
            myLocation = Value
            myCenter.X = Value.X + (ICON.Width \ 2)
            myCenter.Y = Value.Y + (ICON.Height \ 2)
        End Set
    End Property

   Friend Property Center() As Point
      Get
         Return myCenter
      End Get
      Set(ByVal Value As Point)
         myCenter = Value
      End Set
   End Property


    Public Sub AddArtwork(ByVal Artwork As Bitmap, ByVal Frame As TravelDirection)
        myArtWork(CInt(Frame) \ 2) = Artwork
    End Sub

    Friend Sub Animate()
        Select Case myDirection
            Case TravelDirection.North
                myLocation.Y -= mySpeed
                myCenter.Y -= mySpeed
            Case TravelDirection.South
                myLocation.Y += mySpeed
                myCenter.Y += mySpeed
            Case TravelDirection.East
                myLocation.X += mySpeed
                myCenter.X += mySpeed
            Case TravelDirection.West
                myLocation.X -= mySpeed
                myCenter.X -= mySpeed
        End Select
    End Sub

    Friend Function DecideNextMove(ByVal Map As Maps) As Boolean
        Dim x, y As Integer
        Dim cell As Integer

        x = (myLocation.X - EDGE_OFFSET.X) \ CELL_INTERVAL
        y = (myLocation.Y - EDGE_OFFSET.Y) \ CELL_INTERVAL
        ' At intersection ? 
        If x * CELL_INTERVAL + EDGE_OFFSET.X = myLocation.X AndAlso _
           y * CELL_INTERVAL + EDGE_OFFSET.Y = myLocation.Y Then
            Dim pick As Integer() = New Integer() {TravelDirection.North, TravelDirection.South, _
                                                  TravelDirection.East, TravelDirection.West}
            Dim test, skip As Integer
            skip = myDirection
            ' Avoid U-turns
            If skip < 3 Then
                skip = skip Xor 3
            Else
                skip = skip Xor 12
            End If
            cell = (Map.Cell(myLocation) And TravelDirection.AnyRoad)
            Do
                test = pick(Rnd.Next(0, 4)) And cell

            Loop Until (test > 0) AndAlso (test And skip) = 0
            myDirection = CType(test, TravelDirection)
            Return True
        End If

    End Function

    Friend Function Image() As System.Drawing.Image
        Return myArtWork(CInt(myDirection) \ 2)
    End Function

End Class
