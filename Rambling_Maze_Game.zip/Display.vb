Public Class Display
    Inherits System.Windows.Forms.Form
    Private myBuffer As Bitmap
    Private myTopBar As Bitmap
    Private myBotBar As Bitmap
    Private myBarTmp As Bitmap
    Private myCar As Bitmap
    Private myGold As Bitmap
    Private myVan As Bitmap
    Private grxForm As Graphics
    Private grxTopBar As Graphics
    Private grxBotBar As Graphics
    Private grxBuffer As Graphics
    Private mySmallFont As Font = New Font("Lucida Console", 24, FontStyle.Bold)
    Private myLargeFont As Font = New Font("Lucida Console", 148, FontStyle.Bold)
    Private mySplashFont As Font = New Font("Tahoma", 16, FontStyle.Regular)
    Private MySplashList(4) As String
    Private myClockMode As ClockMode
    Private myLivesRect As Rectangle = New Rectangle(0, 0, 160, CELL.Height)
    Private myMapRect As Rectangle = New Rectangle(0, 46, 352, 349)
    Private myArtRect As Rectangle = New Rectangle(0, 0, 352, 349)
    Private myBufRect As Rectangle = New Rectangle(0, 0, 352, 349)
    Private myCounter As Integer
    Private myRadarBrush As SolidBrush = New SolidBrush(Color.White)
    Private myTopChange As Boolean
    Private myBotChange As Boolean
    'Private grxBarTmp As Graphics = Graphics.FromImage(myBarTmp)
    Private myQuitting As Boolean

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Clock As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Clock = New System.Windows.Forms.Timer(Me.components)
        '
        'Clock
        '
        '
        'Display
        '
      'Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.AutoScaleDimensions = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(328, 373)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Display"
        Me.Text = "Rambling"

    End Sub

#End Region


#Region "  UPDATES  "
    ' All updates simply translate their parameters to the appropreate bitmaps

    Friend Sub RadarUpdate(ByVal Item As Sprite)
        Dim x As Integer = (Item.Location.X - EDGE_OFFSET.X) \ CELL_INTERVAL
        Dim y As Integer = (Item.Location.Y - EDGE_OFFSET.Y) \ CELL_INTERVAL
        myRadarBrush.Color = Item.Color
        grxTopBar.FillRectangle(myRadarBrush, x * 2 + 319, y * 2 + 7, 3, 3)
        myTopChange = True
    End Sub
    Friend Sub RadarClear()
        grxTopBar.FillRectangle(Brushes.Green, 316, 4, 33, 36)
        If InPursute Then
            grxTopBar.DrawRectangle(Pens.Red, 316, 4, 32, 36)
            grxTopBar.DrawRectangle(Pens.Red, 317, 5, 30, 34)
        Else
            grxTopBar.DrawRectangle(Pens.DarkGreen, 316, 4, 32, 36)
            grxTopBar.DrawRectangle(Pens.DarkGreen, 317, 5, 30, 34)
        End If

    End Sub

    Friend Sub GoalUpdate(ByVal Level As Integer)
        grxTopBar.FillRectangle(Brushes.Black, 0, 3, 134, CELL.Height)
        If Level >= 1 Then grxTopBar.DrawImageUnscaled(myVan, 4, 5)
        If Level >= 2 Then grxTopBar.DrawImageUnscaled(myGold, 4 + CELL.Width, 5)
        If Level >= 3 Then grxTopBar.DrawImageUnscaled(myGold, 4 + (CELL.Width * 2), 5)
        If Level >= 4 Then grxTopBar.DrawImageUnscaled(myGold, 4 + (CELL.Width * 3), 5)
        myTopChange = True
    End Sub

    Friend Sub CashUpdate(ByVal Amount As Integer)
        Dim msg As String = Amount.ToString("$#0")
        Dim x As SizeF = grxTopBar.MeasureString(msg, mySmallFont)
        grxTopBar.FillRectangle(Brushes.Black, 130, 3, 180, 31)
        grxTopBar.DrawString(msg, mySmallFont, Brushes.LemonChiffon, 312 - x.Width, 5)
        myTopChange = True
    End Sub

    Friend Sub FuelUpdate(ByVal Amount As Integer)
        If Amount < 0 Then Amount = 0
        If Amount > 1000 Then Amount = 1000
        Dim margin As Integer = 4
        Dim gauge As Integer = myTopBar.Width - margin - 40
        Dim level As Integer = (Amount * gauge) \ 1000

        grxTopBar.FillRectangle(Brushes.Black, level + margin, 36, gauge - level, 5)
        If Amount < 100 Then
            grxTopBar.FillRectangle(Brushes.Red, margin, 36, level, 5)
        ElseIf Amount < 300 Then
            grxTopBar.FillRectangle(Brushes.Yellow, margin, 36, level, 5)
        Else
            grxTopBar.FillRectangle(Brushes.Blue, margin, 36, level, 5)
        End If
        myTopChange = True
    End Sub

    Friend Sub MapUpdate(ByRef Artwork As Bitmap, ByRef Player As Sprite)

        If grxForm Is Nothing Then grxForm = Me.CreateGraphics

        ' Center player
        myArtRect.X = Player.Location.X - (CELL_INTERVAL * 2)
        myArtRect.Y = Player.Location.Y - (CELL_INTERVAL * 2)

        grxForm.DrawImage(Artwork, myMapRect, myArtRect, GraphicsUnit.Pixel)
        grxBuffer.DrawImage(Artwork, myBufRect, myArtRect, GraphicsUnit.Pixel)

        If myBotChange Then
            grxForm.DrawImageUnscaled(myBotBar, 0, 395)
            myBotChange = False
        End If
        If myTopChange Then
            grxForm.DrawImageUnscaled(myTopBar, 0, 0)
            myTopChange = False
        End If
    End Sub

    Friend Sub LivesUpdate(ByVal Amount As Integer)
        grxBotBar.FillRectangle(Brushes.Black, 0, 1, CELL.Width * 3 + 4, CELL.Height)
        For x As Integer = 0 To Amount - 1
            grxBotBar.DrawImageUnscaled(myCar, CELL.Width * x + 4, 2)
        Next
        myBotChange = True
    End Sub

    Friend Sub StashUpdate(ByVal Amount As Integer)
        Dim msg As String = Amount.ToString("$#0")
        Dim x As SizeF = grxTopBar.MeasureString(msg, mySmallFont)
        grxBotBar.FillRectangle(Brushes.Black, 352 - x.Width, 2, x.Width + 4, 31)
        grxBotBar.DrawString(msg, mySmallFont, Brushes.LemonChiffon, 352 - x.Width, 4)
        myBotChange = True
    End Sub

#End Region

#Region "  SPLASH SCREEN  "
    Public Sub ShowSplash()
        ' This is the first thing called, so it has to set up everything it uses
        Debug.WriteLine("SPLASH ENTER")

        Dim fnt As Font = New Font("Tahoma", 48, FontStyle.Bold)

        ' Set form's size / Cache graphics
        Me.Height += 430 - Me.ClientSize.Height
        Me.Width += 352 - Me.ClientSize.Width
        Me.Text = "RAMBLER"
        grxForm = Me.CreateGraphics

        ' Eliminate flicker
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint Or ControlStyles.UserPaint, True)

        ' Create memory buffers and graphics
        myBuffer = New Bitmap(352, 349, grxForm)
        grxBuffer = Graphics.FromImage(myBuffer)

        myTopBar = New Bitmap(352, 46, grxForm)
        grxTopBar = Graphics.FromImage(myTopBar)

        myBotBar = New Bitmap(352, 36, grxForm)
        grxBotBar = Graphics.FromImage(myBotBar)
        myBarTmp = New Bitmap(352, 46, grxForm)

        ' Set colors
        grxTopBar.Clear(Color.Black)
        grxBotBar.Clear(Color.Black)
        grxBuffer.Clear(Color.Black)

        ' Draw text
        grxBuffer.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        grxBuffer.DrawString("CHILDSPLAY SOFTWARE", mySplashFont, Brushes.Lavender, 55, 10)
        grxBuffer.DrawString("Presents:", mySplashFont, Brushes.Lavender, 122, 40)
        grxBuffer.DrawString("RAMBLER", fnt, Brushes.LightSteelBlue, 10, 80)
        grxBuffer.DrawString("RAMBLER", fnt, Brushes.SlateBlue, 12, 82)
        grxBuffer.SmoothingMode = Drawing2D.SmoothingMode.None
        SplashToggle(0)

        fnt.Dispose()
        Me.Show()
        SplashMessage("Loading: ARTWORK")
        Debug.WriteLine("SPLASH EXIT")
    End Sub

   Public Sub SplashToggle(ByVal prompt As Integer)
      grxBotBar.Clear(Color.Black)
      If Prompt > 0 Then
         grxBotBar.DrawString("PRESS ANY KEY TO BEGIN", mySplashFont, Brushes.LemonChiffon, 48, 6)
      Else
         grxBotBar.DrawString("COPYRIGHT 2004 LARRY SERFLATEN", mySplashFont, Brushes.Gray, -1, 6)
      End If
      myBotChange = True
   End Sub

   Public Sub SplashMessage(ByVal text As String)
      For idx As Integer = 0 To 3
         MySplashList(idx) = MySplashList(idx + 1)
      Next
      MySplashList(4) = Text

      grxBuffer.FillRectangle(Brushes.Green, 18, 200, 318, 130)

      For idx As Integer = 0 To 4
         grxBuffer.DrawString(MySplashList(idx), mySplashFont, Brushes.Lavender, 18, 200 + idx * 25)
      Next

      Display_Paint(Nothing, Nothing)
   End Sub

#End Region

   Public Sub CacheIcons(ByVal map As Maps)
      myCar = New Bitmap(Icon.Width, Icon.Height, grxForm)
      myVan = New Bitmap(Icon.Width, Icon.Height, grxForm)
      myGold = New Bitmap(Icon.Width, Icon.Height, grxForm)
      Map.GetIcons(myCar, myGold, myVan)
   End Sub

   Public Sub ShowFullMap(ByVal artwork As Image)
      myArtRect.X = 0
      myArtRect.Y = 0
      grxBuffer.Clear(Color.Black)
      grxBuffer.DrawImage(Artwork, myArtRect, New Rectangle(0, 0, Artwork.Width, Artwork.Height), GraphicsUnit.Pixel)
      Me.Invalidate()
   End Sub

   Friend Sub SetClock(ByVal mode As ClockMode)
      myClockMode = Mode
      Select Case Mode
         Case GameCode.ClockMode.NewGame, GameCode.ClockMode.Demo, GameCode.ClockMode.NextMap
            Clock.Interval = 150
         Case GameCode.ClockMode.CountDown
            Clock.Interval = 500
            myCounter = 5
            CountDownPrompt()
         Case GameCode.ClockMode.Play
         Case GameCode.ClockMode.Fuel
            Clock.Interval = 50
            myCounter = 20
         Case GameCode.ClockMode.Quit
            Clock.Enabled = False
      End Select
      Clock.Enabled = True
   End Sub

    Private Sub CountDownPrompt()
        Debug.WriteLine("CountDown prompt " & CStr(myCounter))
        With grxForm
            .DrawImageUnscaled(myBuffer, 0, 46)
            If myCounter > 0 Then
                .DrawString("GET READY", mySmallFont, Brushes.LemonChiffon, 80, 53)
                .DrawString(CStr(myCounter), myLargeFont, Brushes.LemonChiffon, 77, 140)
            End If
        End With
    End Sub

    Private Sub Clock_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Clock.Tick
        Debug.WriteLine("TICK " & myClockMode.ToString)


        Select Case myClockMode
            Case GameCode.ClockMode.NewGame
                Clock.Enabled = False
                grxBotBar.Clear(Color.Black)
                NewGame()
            Case GameCode.ClockMode.CountDown
                myCounter -= 1
                CountDownPrompt()
                If myCounter = 0 Then
                    myClockMode = GameCode.ClockMode.Play
                    Clock.Interval = 150
                End If
            Case GameCode.ClockMode.Siren
            Case GameCode.ClockMode.NextMap
                Clock.Enabled = False
                NextMap()
            Case GameCode.ClockMode.Play
                Clock.Enabled = False
                GameLoop()
            Case GameCode.ClockMode.Demo
                Clock.Enabled = False
                Demo()
            Case GameCode.ClockMode.Fuel
                myCounter -= 1
                myFuel += 10
                If myFuel > 1000 Then myFuel = 1000
                FuelUpdate(myFuel)
                If (UserInput <> 0) OrElse (myFuel >= 1000) Then
                    Debug.WriteLine("Fuel STOPPED")
                    myClockMode = GameCode.ClockMode.Play
                    Clock.Enabled = False
                    UserInput = 48
                End If
        End Select
    End Sub



    Private Sub Display_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        ' Moves all bitmaps to the screen, required when part 
        ' of the form becomes invalidated 
        If grxForm Is Nothing Then
            grxForm = Me.CreateGraphics
        End If
        grxForm.DrawImageUnscaled(myBuffer, 0, 46)
        grxForm.DrawImageUnscaled(myTopBar, 0, 0)
        grxForm.DrawImageUnscaled(myBotBar, 0, 395)
        myTopChange = False
        myBotChange = False

        Debug.WriteLine("PAINT")

    End Sub

    Private Sub Display_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        CloseSounds()
        UserInput = -1
        grxBuffer.Dispose()
        grxTopBar.Dispose()
        grxBotBar.Dispose()
        myTopBar.Dispose()
        myBotBar.Dispose()
        myBuffer.Dispose()
        myBarTmp.Dispose()
    End Sub

    Private Sub Display_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Debug.WriteLine("LOAD")
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint Or ControlStyles.UserPaint, True)
    End Sub

    Private Sub Display_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        UserInput = e.KeyCode
    End Sub

    Protected Overrides Sub OnPaintBackground(ByVal pevent As System.Windows.Forms.PaintEventArgs)
        ' Stop flickering!
    End Sub

End Class
