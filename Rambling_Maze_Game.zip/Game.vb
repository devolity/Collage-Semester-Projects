Module GameCode
#Region "  GENERAL DECLARATIONS  "

    ' Enumerations 
    <Flags()> _
    Public Enum TravelDirection   ' Governs icon image, and motion
        North = 1
        South = 2
        East = 4
        West = 8
        Vertical = North Or South
        Horizontal = East Or West
        AnyRoad = Vertical Or Horizontal
    End Enum

    <Flags()> _
    Public Enum RoadObject      ' Indicates whats on the map
        Grass = 0
        Home = 16
        Fuel = 32
        Cash = 64
        Gold = 128
        Van = 256
        Life = 1024
        Cop = 2048
        Player = 4096
        PrizeType = Cash Or Gold Or Van
        ParkType = Home Or Fuel
        AnyItem = ParkType Or PrizeType Or Cop Or Life
    End Enum

    Public Enum ClockMode      ' Clock disconnects routines
        CountDown
        Demo
        Halt
        Lives
        Fuel
        NewGame
        NextMap
        Pause
        Play
        Siren
        Quit
    End Enum

    Public Enum CarID         ' Convenience  (myCars array)
        Player = 0
        Van = 1
        Cop1 = 2
        Cop2 = 3
        Alarm1 = 4
        Alarm2 = 5
    End Enum


    Private Declare Function GetInputState Lib "user32" () As Integer

    ' Graphic constants
    Public ReadOnly CELL As Size = New Size(32, 32)
    Public ReadOnly ICON As Size = New Size(29, 29)
    Public ReadOnly EDGE_OFFSET As Point = New Point(184, 200)
    Public Const CELL_INTERVAL As Integer = 80
    Public Const MAX_MAP As Integer = 4
    Public Const BONUS_MAP As Integer = 6

    ' Project variables
    Public UserInput As Integer
    Public Rnd As Random = New Random

#End Region

    ' Graphic objects
    Private myCars(5) As Sprite
    Private myMaps As Maps
    Private myGraphics As Graphics
    Private myBlackIcon As Bitmap
    Private myGame As New Display

    ' Game variables
    Public myFuel As Integer
    Public InPursute As Boolean
    Private myLevel As Integer
    Private myCash As Integer
    Private myStash As Integer
    Private myLives As Integer
    Private myGoal As Integer
    Private myLifeTrigger As Integer
    Private myChaseLevel As Integer
    Private myDelay As Integer
    Private myHomeLocation As Point
    Private myFuelLocation As Point
    Private myVanTrigger As Boolean
    Private myFueling As Integer
    Private myCop2 As Boolean
    Private myVolume As Integer





    <STAThread()> _
    Public Sub main()

        ' Show (Splash) Display
        myGame.ShowSplash()
        myGame.Refresh()
        System.Threading.Thread.Sleep(500)
        myGraphics = myGame.CreateGraphics
        myMaps = New Maps
        ' Load Artwork
        If myMaps.LoadArtwork() Then
            myBlackIcon = New Bitmap(CELL.Width, CELL.Height, myGraphics)
            Graphics.FromImage(myBlackIcon).Clear(Color.Black)
            myMaps.CreateCompatableBitmaps(myGraphics)
            myMaps.NewMap(2)
            myGame.SplashMessage("ARTWORK OK")
            myGame.SplashMessage("Initializing: ICONS")
            myGame.CacheIcons(myMaps)
            CreateCarIcons()
            myGame.SplashMessage("Preparing: MUSIC")
            PlaySong(True)
        Else
            myGame.SplashMessage("ARTWORK FAILED!")
            MsgBox("Needed map files were not found.", MsgBoxStyle.Critical, "Game Aborted")
            myGame.Close()
            Exit Sub
        End If
        myGame.SplashMessage("Starting Demo....")
        myGame.SetClock(ClockMode.Demo)
        Application.Run(myGame)
    End Sub

    Public Sub GameLoop()
      Dim plrs, tmr, inp As Integer
        Dim intersect As Integer
        Dim diff, tick As Long

        SetMapSpeed()
        intersect = 0
        myCars(CarID.Player).Speed = 0
        UserInput = 0
        DrawCars()
        myGame.MapUpdate(myMaps.CityMap, myCars(CarID.Player))

        plrs = 2
        If myCop2 Then plrs = 3
        tick = Now.Ticks
        Do

            myGame.RadarClear()

            ' Erase / Animate
            For car As Integer = 0 To plrs
                myMaps.MapGraphics.DrawImageUnscaled(myBlackIcon, myCars(Car).Location)
                myCars(Car).Animate()
                If Car <> CarID.Player Then
                    myCars(Car).DecideNextMove(myMaps)
                End If
                myGame.RadarUpdate(myCars(Car))
            Next

            ' Draw
            myMaps.RefreshArea(myCars(CarID.Player))

            myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Player).Image, myCars(CarID.Player).Location.X + 2, myCars(CarID.Player).Location.Y + 2)
            myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Van).Image, myCars(CarID.Van).Location.X + 2, myCars(CarID.Van).Location.Y + 2)

            If myChaseLevel > 0 Then
                ' Re-decide direction for cops
                If (myChaseLevel > Rnd.Next(1, 2000)) AndAlso (17 > Rnd.Next(1, 20)) Then
                    'Debug.WriteLine("CHASE LEVEL: " & CStr(myChaseLevel))
                    SteerTowardPlayer(myCars(CarID.Cop1))
                    If plrs = 3 Then SteerTowardPlayer(myCars(CarID.Cop2))
                End If

                ' Light the cherries (cop lights)
                If (tmr And 16) > 0 Then
                    InPursute = True
                    myCars(CarID.Alarm1).Direction = myCars(CarID.Cop1).Direction
                    myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Alarm1).Image, myCars(CarID.Cop1).Location.X + 2, myCars(CarID.Cop1).Location.Y + 2)
                    If plrs = 3 Then
                        myCars(CarID.Alarm2).Direction = myCars(CarID.Cop2).Direction
                        myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Alarm2).Image, myCars(CarID.Cop2).Location.X + 2, myCars(CarID.Cop2).Location.Y + 2)
                    End If
                Else
                    InPursute = False
                    myCars(CarID.Alarm2).Direction = myCars(CarID.Cop1).Direction
                    myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Alarm2).Image, myCars(CarID.Cop1).Location.X + 2, myCars(CarID.Cop1).Location.Y + 2)
                    If plrs = 3 Then
                        myCars(CarID.Alarm1).Direction = myCars(CarID.Cop2).Direction
                        myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Alarm1).Image, myCars(CarID.Cop2).Location.X + 2, myCars(CarID.Cop2).Location.Y + 2)
                    End If
                End If
            Else
                PlaySiren(False)
                If InPursute Then
                    InPursute = False
                End If
                myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Cop1).Image, myCars(CarID.Cop1).Location.X + 2, myCars(CarID.Cop1).Location.Y + 2)
                If plrs = 3 Then myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Cop2).Image, myCars(CarID.Cop2).Location.X + 2, myCars(CarID.Cop2).Location.Y + 2)
            End If

            myGame.MapUpdate(myMaps.CityMap, myCars(CarID.Player))

            ' Wait / dependant on # of ticks that passed
            diff = (Now.Ticks - tick) \ 10000
            tick = Now.Ticks
            If diff < 0 Then diff = 0
            If diff > myDelay Then diff = myDelay
            System.Threading.Thread.Sleep(CInt(myDelay - diff))

 
            ' Read input
            tmr += 1
            If tmr >= 1024 Then tmr = 0
            If (tmr And 15) = 15 Then
                ' Fuel consumption
                If myFueling < 2 Then
                    myFuel -= 2
                    myGame.FuelUpdate(myFuel)
                Else
                    If myCash > 0 Then
                        ' Paying for gas
                        myCash -= 1
                        myGame.CashUpdate(myCash)
                    Else
                        ' Stealing gas!
                        If myChaseLevel > 0 Then
                            myChaseLevel += 10
                        End If
                    End If
                End If
                ' Catch Control box clicks (Stops 'Not Responding')
                Application.DoEvents()
            ElseIf (tmr And 3) = 0 Then
                If myChaseLevel > 0 Then myChaseLevel -= 1
                ' check for key input
                inp = GetInputState
                If inp > 0 Then
                    Application.DoEvents()
                    Debug.WriteLine("INPUT ACCEPTED " & CStr(UserInput))
                End If

            End If


            intersect -= myCars(CarID.Player).Speed
            ' When player is at an intersection...
            If intersect <= 0 Then
                ' Process input
                Select Case UserSteer(myCars(CarID.Player))
                    Case ClockMode.Play
                        If myCars(CarID.Player).Speed > 0 Then intersect = CELL_INTERVAL
                    Case ClockMode.NewGame
                        myGame.SetClock(ClockMode.NewGame)
                        Exit Sub
                    Case ClockMode.Quit
                        myGame.SetClock(ClockMode.Quit)
                        myGame.Close()
                        myMaps.Dispose()
                        Exit Sub
                    Case ClockMode.NextMap
                        PlaySound(Sounds.LocalFile.NewMap)
                        myLevel += 1
                        myGame.SetClock(ClockMode.NextMap)
                        Exit Sub
                End Select
                ' Process hit tests
                If IntersectionHitTests() Then Exit Sub
            'Debug.WriteLine("LOC: " & myCars(CarID.Player).Location.X.ToString & "  " & myCars(CarID.Player).Location.Y.ToString)

                ' Adjust siren volume 
                If myChaseLevel > 0 Then
               Dim dx As Integer = (myCars(CarID.Cop1).Location.X - myCars(CarID.Player).Location.X)
               Dim dy As Integer = (myCars(CarID.Cop1).Location.Y - myCars(CarID.Player).Location.Y)
               Dim v As Integer = CInt(Math.Sqrt(Math.Sqrt(dx * dx + dy * dy))) ' * 12
               Dim nv As Integer

               If v > 12 Then
                  ' distant volume
                  nv = 128 - (v * 3)
               Else
                  ' near volume
                  nv = 512 - (v * 6)
               End If

               ' Avoid making many small changes
               If Math.Abs(myVolume - nv) > 15 Then
                  myVolume = nv
                  SirenVolume(myVolume)
               End If

            End If
         End If

         ' Fueling done Test
         If myFueling > 0 And UserInput <> 0 Then
            myCars(CarID.Player).Speed = 4
            myFueling = 0
            PlaySound(Sounds.LocalFile.Gold)

         End If

         ' Other timed tests
         If (tmr And 3) = 3 Then

            If myFueling > 0 Then myFueling -= 1

            ' Catch the Van
            If Math.Abs(myCars(CarID.Van).Center.X - myCars(CarID.Player).Center.X) < CELL.Width AndAlso _
               Math.Abs(myCars(CarID.Van).Center.Y - myCars(CarID.Player).Center.Y) < CELL.Height Then
               PlaySound(Sounds.LocalFile.Van)
               Debug.WriteLine("CATCH: " & myGoal.ToString & "  TRI:" & myVanTrigger.ToString)
               System.Threading.Thread.Sleep(50)
               If myChaseLevel > 0 Then
                  myChaseLevel += 500
               Else
                  PlaySiren(True)
               End If
               myChaseLevel += 500
               myCash += 250
               myMaps.MapGraphics.DrawImageUnscaled(myBlackIcon, myCars(CarID.Van).Location)
               myCars(CarID.Van).Location = myMaps.Vacant
               myCars(CarID.Van).DecideNextMove(myMaps)
               myGame.CashUpdate(myCash)
               If myGoal = 1 Then
                  myVanTrigger = True
                  myGoal = 0
                  myGame.GoalUpdate(myGoal)
               End If

            End If

            ' Caught by Cops
            If (myCash > 0) And (Not myCars(CarID.Player).Location.Equals(myHomeLocation)) Then
               ' test for cops
               inp = 0
               If Math.Abs(myCars(CarID.Cop1).Center.X - myCars(CarID.Player).Center.X) < CELL.Width AndAlso _
                  Math.Abs(myCars(CarID.Cop1).Center.Y - myCars(CarID.Player).Center.Y) < CELL.Height Then
                  inp = 1
               End If
               If myCop2 Then
                  If Math.Abs(myCars(CarID.Cop2).Center.X - myCars(CarID.Player).Center.X) < CELL.Width AndAlso _
                     Math.Abs(myCars(CarID.Cop2).Center.Y - myCars(CarID.Player).Center.Y) < CELL.Height Then
                     inp = 1
                  End If
               End If

               If inp > 0 Then
                  ' Got caught, take money and send him home...
                  PlaySound(Sounds.LocalFile.Crash)
                  PlaySiren(False)
                  System.Threading.Thread.Sleep(1000)
                  myCash = 0
                  myFueling = 0
                  myLives -= 1
                  intersect = 0
                  myChaseLevel = 0
                  myMaps.MapGraphics.DrawImageUnscaled(myBlackIcon, myCars(CarID.Player).Location)
                  myCars(CarID.Player).Location = myHomeLocation
                  myCars(CarID.Player).Speed = 0
                  ' Update display
                  myGame.CashUpdate(myCash)
                  myGame.LivesUpdate(myLives)
                  myGame.MapUpdate(myMaps.CityMap, myCars(CarID.Player))
                  ' End of game
                  If myLives < 0 Then
                     PlaySound(Sounds.LocalFile.GameOver)
                     myCars(CarID.Player).Speed = 4
                     myLevel = MAX_MAP
                     myGame.SetClock(ClockMode.Demo)
                     Exit Sub
                  End If
               End If
            End If

         End If

      Loop

    End Sub

    Private Function IntersectionHitTests() As Boolean
        Dim cel As Integer
        ' Checks to see what the player hit
        cel = myMaps.Cell(myCars(CarID.Player).Location)

        If (cel And RoadObject.Cash) = RoadObject.Cash Then
            PlaySound(Sounds.LocalFile.Cash)
         myCash += 5 * myLevel + 5
            If myChaseLevel > 0 Then myChaseLevel += 50
            myMaps.Remove(RoadObject.Cash, myCars(CarID.Player).Location)
            myMaps.Insert(RoadObject.Cash, myMaps.Vacant)
        ElseIf (cel And RoadObject.Gold) = RoadObject.Gold Then
            PlaySound(Sounds.LocalFile.Gold)
            If (myGoal = 4) AndAlso (myLevel And 7) = 1 Then PlaySong(True)
         myCash += 100 * (Int(myLevel \ 2) + 1)
            If myChaseLevel > 0 Then myChaseLevel += 200
            myMaps.Remove(RoadObject.Gold, myCars(CarID.Player).Location)
            If myGoal > 1 Then
                myGoal -= 1
                myGame.GoalUpdate(myGoal)
            End If
        ElseIf (cel And RoadObject.Home) = RoadObject.Home Then
            If myCash > 0 Then PlaySound(Sounds.LocalFile.Stash)
            myStash += myCash
            myCash = 0
            myGame.StashUpdate(myStash)
            If myVanTrigger Then
                myVanTrigger = False
                myLevel += 1
                myGame.SetClock(ClockMode.NextMap)
                PlaySiren(False)
                Return True
            End If
        ElseIf (cel And RoadObject.Fuel) = RoadObject.Fuel Then

            'Debug.WriteLine("FUELING: " & myFuel.ToString & "  IN:" & UserInput.ToString)
            If myFueling < 1 AndAlso myFuel < 1080 Then
                PlaySound(Sounds.LocalFile.Fueling)
                myFueling = 5000
                UserInput = 0
                myCars(CarID.Player).Speed = 0
                myGame.SetClock(ClockMode.Fuel)
            ElseIf myFuel >= 1000 Then
                myFueling = 0
            End If
            If UserInput <> 0 Then
                myFueling = 20
            End If
        End If
        myGame.CashUpdate(myCash)

    End Function


    Private Sub SteerTowardPlayer(ByVal cop As Sprite)
      Dim cel As Integer
        Dim x, y As Integer
        Dim plr As Sprite

        ' Test for intersection 
        x = (cop.Location.X - EDGE_OFFSET.X) \ CELL_INTERVAL
        x = x * CELL_INTERVAL + EDGE_OFFSET.X
        ' Debug.WriteLine(" X TEST  X:" & CStr(x) & "   cstr(Cop.X:" & cop.Location.X)

        If x = cop.Location.X Then
            y = (cop.Location.Y - EDGE_OFFSET.Y) \ CELL_INTERVAL
            y = y * CELL_INTERVAL + EDGE_OFFSET.Y
            '    Debug.WriteLine(" Y TEST  Y:" & CStr(y) & "   cstr(Cop.Y:" & cop.Location.Y)
            If y = cop.Location.Y Then
                '       Debug.WriteLine("INTERSECTION PASSED")
                plr = myCars(CarID.Player)

                cel = myMaps.Cell(cop.Location) And TravelDirection.AnyRoad
                x = plr.Location.X - cop.Location.X
                y = plr.Location.Y - cop.Location.Y

                ' close the gap on the greater distance
                If Math.Abs(x) > Math.Abs(y) Then
                    If x < 0 Then
                        If (cel And TravelDirection.West) = TravelDirection.West Then
                            cop.Direction = TravelDirection.West
                        End If
                    Else
                        If (cel And TravelDirection.East) = TravelDirection.East Then
                            cop.Direction = TravelDirection.East
                        End If
                    End If
                Else
                    If y < 0 Then
                        If (cel And TravelDirection.North) = TravelDirection.North Then
                            cop.Direction = TravelDirection.North
                        End If
                    Else
                        If (cel And TravelDirection.South) = TravelDirection.South Then
                            cop.Direction = TravelDirection.South
                        End If
                    End If

                End If
                '      Debug.WriteLine("Deciding " & cop.Direction.ToString)

            End If
        End If

    End Sub

    Public Function UserSteer(ByVal plr As Sprite) As ClockMode
        Dim pik As Integer

        Select Case UserInput
            Case Keys.A, Keys.Left
                pik = TravelDirection.West
            Case Keys.D, Keys.Right
                pik = TravelDirection.East
            Case Keys.W, Keys.Up
                pik = TravelDirection.North
            Case Keys.S, Keys.Down
                pik = TravelDirection.South
            Case Keys.F1
                Return ClockMode.NewGame
            Case Keys.F5
                Return ClockMode.NextMap
            Case Keys.Escape, -1
                myMaps.Dispose()
                Return ClockMode.Quit
            Case Else
                pik = -1
        End Select

        'Debug.WriteLine("Picked: " & pik.ToString)
        'Debug.WriteLine("Cell: " & (myMaps.Cell(plr.Location) And TravelDirection.AnyRoad))
        'System.Threading.Thread.Sleep(500)



        If (myMaps.Cell(myCars(CarID.Player).Location) And pik) = pik Then
            plr.Direction = CType(pik, TravelDirection)
            If myFuel > 0 Then
                plr.Speed = 4
            Else
                plr.Speed = 2
            End If
        ElseIf (myMaps.Cell(plr.Location) And plr.Direction) = 0 Then
            plr.Speed = 0
        End If

        Return ClockMode.Play

    End Function

    Public Sub NewGame()
        ' Init counter variables
        CloseSounds()
        myLevel = 0
        myDelay = 20
        myLifeTrigger = 5000
        myChaseLevel = 0
        ' Init display variables
        With myGame
            myCash = 0
            .CashUpdate(myCash)
            myStash = 0
            .StashUpdate(myStash)
            myLives = 3
            .LivesUpdate(myLives)
            myGoal = 4
            .GoalUpdate(myGoal)
            myFuel = 1000
            .FuelUpdate(myFuel)
            '.Invalidate()
        End With
        myGame.SetClock(ClockMode.NextMap)
    End Sub

    Public Sub NextMap()
        Dim cash As Integer
        Debug.WriteLine("New map level " & CStr(myLevel))

        ' Choose a map
        myMaps.NewMap(myLevel Mod (MAX_MAP + 1))
        ' Add Cars / Direction
        For car As Integer = 0 To 3
            myCars(car).Location = myMaps.Vacant
            myCars(car).DecideNextMove(myMaps)
        Next
        myCars(CarID.Player).Color = Color.SkyBlue
        myCars(CarID.Van).Color = Color.White
        myCars(CarID.Cop1).Color = Color.Red
        myCars(CarID.Cop2).Color = Color.Red

        ' Add Home / Gas
        myCash = 0
        myGoal = 4
        myFuel = 1000
        myFueling = 0
        myGame.FuelUpdate(myFuel)
        myGame.CashUpdate(myCash)
        myGame.GoalUpdate(myGoal)

        myChaseLevel = 0
        NewHome()
        ' Make player appear upright
        myCars(CarID.Player).Direction = TravelDirection.East
        ' Add gold 
        myMaps.Insert(RoadObject.Gold, myMaps.Vacant)
        myMaps.Insert(RoadObject.Gold, myMaps.Vacant)
        myMaps.Insert(RoadObject.Gold, myMaps.Vacant)

        ' Add Cash
        cash = 12
        If myLevel >= ((MAX_MAP + 1) * 3) Then
            cash = 4
        ElseIf myLevel >= (MAX_MAP + 1) Then
            cash = 8
        End If
        For itr As Integer = 1 To cash
            myMaps.Insert(RoadObject.Cash, myMaps.Vacant)
        Next
        PlaySound(Sounds.LocalFile.NewMap)
        ' Start Game loop
        myGame.ShowFullMap(myMaps.CityMap)
        myGame.RadarClear()
        ' Paint the new map
        Application.DoEvents()
        myGame.SetClock(ClockMode.CountDown)   'Countdown 

    End Sub


    Private Sub NewHome()
        Dim cell As Integer
        Do
            ' pick a corner for Home 
            Do
                myHomeLocation = myMaps.Vacant
                cell = myMaps.Cell(myHomeLocation)

            Loop Until ((cell And TravelDirection.Horizontal) <> TravelDirection.Horizontal) AndAlso _
                       ((cell And TravelDirection.Vertical) <> TravelDirection.Vertical)

            ' Pick a straight away for gas
            Do
                myFuelLocation = myMaps.Vacant
                cell = myMaps.Cell(myFuelLocation)
         Loop Until (cell = TravelDirection.Horizontal) OrElse _
                    (cell = TravelDirection.Vertical)

            ' Make sure they are not too close 
        Loop Until (Math.Abs(myHomeLocation.X - myFuelLocation.X) > 400) Or (Math.Abs(myHomeLocation.Y - myFuelLocation.Y) > 400)


        ' Add to map
        myMaps.Insert(RoadObject.Home, myHomeLocation)
        myMaps.Insert(RoadObject.Fuel, myFuelLocation)
        ' Player starts at home 
        myCars(CarID.Player).Location = myHomeLocation
    End Sub


    Friend Sub Demo()
        Dim tmr, inp, clk, car As Integer

        ' Update display
        InPursute = False
        myGame.CashUpdate(0)
        myGame.FuelUpdate(1000)
        myGame.GoalUpdate(1)

        ' Choose a map
        myMaps.NewMap(myLevel)

        ' Add cars
        For car = 1 To 3
            myCars(car).Location = myMaps.Vacant
            myCars(car).DecideNextMove(myMaps)
        Next
        myCars(CarID.Player).Color = Color.SkyBlue
        myCars(CarID.Van).Color = Color.White
        myCars(CarID.Cop1).Color = Color.Red
        myCars(CarID.Cop2).Color = Color.Red

        UserInput = 0

        Do While UserInput = 0
            ' Erase
            For car = 1 To 3
                myMaps.MapGraphics.DrawImageUnscaled(myBlackIcon, myCars(car).Location.X, myCars(car).Location.Y)
            Next
            ' Animate
            inp = 0
            For car = 1 To 3
                myCars(car).Animate()
                If myCars(car).DecideNextMove(myMaps) Then inp += 1
            Next

            ' Decide
            If inp > 0 Then
                myGame.RadarClear()
                myGame.RadarUpdate(myCars(CarID.Van))
                myGame.RadarUpdate(myCars(CarID.Cop1))
                myGame.RadarUpdate(myCars(CarID.Cop2))
            End If

            ' Draw
            myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Van).Image, myCars(CarID.Van).Location.X + 2, myCars(CarID.Van).Location.Y + 2)
            myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Cop2).Image, myCars(CarID.Cop2).Location.X + 2, myCars(CarID.Cop2).Location.Y + 2)
            myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Cop1).Image, myCars(CarID.Cop1).Location.X + 2, myCars(CarID.Cop1).Location.Y + 2)
            myGame.MapUpdate(myMaps.CityMap, myCars(CarID.Van))

            ' Wait
            System.Threading.Thread.Sleep(20)
            tmr = (tmr + 1) And 127
            If (tmr And 63) = 0 Then
                myGame.SplashToggle(tmr And 64)
            ElseIf (tmr And 7) = 0 Then
                ' check for key input
                Application.DoEvents()
            End If

            ' Map change
            clk += 1
            If clk > 1500 Then
                myLevel += 1
                If myLevel > MAX_MAP Then myLevel = 0
                myGame.SetClock(ClockMode.Demo)
                Exit Sub
            End If

            ' User abort
            If UserInput <> 0 Then
                Select Case UserInput
                    Case Keys.Escape, -1
                        myGame.SetClock(ClockMode.Quit)
                        myGame.Close()
                        myMaps.Dispose()
                    Case Else
                        myGame.SetClock(ClockMode.NewGame)
                End Select
                Exit Sub
            End If
        Loop

    End Sub

    Private Sub CreateCarIcons()
        Dim src As Rectangle = New Rectangle(0, 0, ICON.Width, ICON.Height)
        Dim mbl As Sprite

        mbl = New Sprite(myMaps.Vacant)
        mbl.Speed = 4
        src.X = 0
        src.Y = ICON.Height * 2
        AddCarIconDirections(mbl, src)
        mbl.Direction = TravelDirection.East
        myCars(CarID.Player) = mbl

        mbl = New Sprite(myMaps.Vacant)
        mbl.Speed = 4
        src.X = 0
        src.Y = 0
        AddCarIconDirections(mbl, src)
        mbl.Direction = TravelDirection.West
        myCars(CarID.Van) = mbl

        mbl = New Sprite(myMaps.Vacant)
        mbl.Speed = 4
        src.X = 0
        src.Y = ICON.Height * 4
        AddCarIconDirections(mbl, src)
        mbl.Direction = TravelDirection.South
        myCars(CarID.Cop1) = mbl

        mbl = New Sprite(myMaps.Vacant)
        mbl.Speed = 4
        src.X = 0
        src.Y = ICON.Height * 4
        AddCarIconDirections(mbl, src)
        mbl.Direction = TravelDirection.South
        myCars(CarID.Cop2) = mbl

        mbl = New Sprite(myMaps.Vacant)
        mbl.Speed = 4
        src.X = 0
        src.Y = ICON.Height * 6
        AddCarIconDirections(mbl, src)
        mbl.Direction = TravelDirection.South
        myCars(CarID.Alarm1) = mbl

        mbl = New Sprite(myMaps.Vacant)
        mbl.Speed = 4
        src.X = 0
        src.Y = ICON.Height * 8
        AddCarIconDirections(mbl, src)
        mbl.Direction = TravelDirection.South
        myCars(CarID.Alarm2) = mbl
    End Sub

    Private Sub AddCarIconDirections(ByVal Mbl As Sprite, ByVal Src As Rectangle)
        AddIcon(Mbl, Src, TravelDirection.West)
        Src.X += ICON.Width
        AddIcon(Mbl, Src, TravelDirection.East)
        Src.X = 0
        Src.Y += ICON.Height
        AddIcon(Mbl, Src, TravelDirection.South)
        Src.X = ICON.Width
        AddIcon(Mbl, Src, TravelDirection.North)
    End Sub


    Private Sub AddIcon(ByVal Car As Sprite, ByVal Src As Rectangle, ByVal Frame As TravelDirection)
        Dim bmp As Bitmap
        Dim grx As Graphics
        Dim dst As Rectangle = New Rectangle(0, 0, ICON.Width, ICON.Height)

        bmp = New Bitmap(ICON.Width, ICON.Height, myGraphics)
        grx = Graphics.FromImage(bmp)
        grx.DrawImage(myMaps.Mobile, dst, Src, GraphicsUnit.Pixel)
        Car.AddArtwork(bmp, Frame)
        grx.Dispose()

    End Sub


    Private Sub SetMapSpeed()
        Dim lvl As Integer
        ' Difficulty settings (Speed / # of Cops)
        lvl = MAX_MAP + 1
        Select Case myLevel
            Case 0 To lvl - 1
                myDelay = 25
                myCop2 = False
            Case lvl To lvl * 2 - 1
                myDelay = 20
                myCop2 = False
            Case lvl * 2 To lvl * 3 - 1
                myDelay = 25
                myCop2 = True
            Case lvl * 3 To lvl * 4 - 1
                myDelay = 20
                myCop2 = False
            Case Else
                myDelay = 10
                myCop2 = True
        End Select
    End Sub

    Private Sub DrawCars()
        If myCop2 Then myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Cop2).Image, myCars(CarID.Cop2).Location.X + 2, myCars(CarID.Cop1).Location.Y + 2)
        myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Van).Image, myCars(CarID.Van).Location.X + 2, myCars(CarID.Van).Location.Y + 2)
        myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Cop1).Image, myCars(CarID.Cop1).Location.X + 2, myCars(CarID.Cop1).Location.Y + 2)
        myMaps.MapGraphics.DrawImageUnscaled(myCars(CarID.Player).Image, myCars(CarID.Player).Location.X + 2, myCars(CarID.Player).Location.Y + 2)
    End Sub

End Module
