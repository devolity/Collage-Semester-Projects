Imports Rambling.GameCode

Public Class Maps

    Implements IDisposable

    Private Enum Img
        Home = 0
        Fuel = 1
        Gold = 2
        Cash = 3
        Life = 4
    End Enum

    Private myRoadMaps As Bitmap
    Private myCityMap As Bitmap
    Private myCars As Bitmap
    Private myPrizes As Bitmap
    Private myIcons(7) As Bitmap

    Private myRoad As Integer(,)
    Private myGenerator As Random = New Random
    Private grxCityMap As Graphics

    Private myCityRect As Rectangle = New Rectangle(0, 0, 1376, 1568)
    Private myMapRect As Rectangle = New Rectangle(0, 0, 86, 98)
    Private myIconRect As Rectangle = New Rectangle(0, 0, ICON.Width, ICON.Height)
    Private myItemRect As Rectangle = New Rectangle(0, 0, ICON.Width, ICON.Height)


    Friend Function LoadArtwork() As Boolean
        ' Try loading the files (made an "all or none" operation)
        Try
            myCars = DirectCast(Bitmap.FromFile("..\images\vehicals.gif"), Bitmap)
            myPrizes = DirectCast(Bitmap.FromFile("..\images\goodies.gif"), Bitmap)
            myRoadMaps = DirectCast(Bitmap.FromFile("..\images\maps.gif"), Bitmap)
            Return True
        Catch ex As Exception
            ' Somethings wrong, so release any that didn't work
            Dispose()
            Return False
        End Try

    End Function

    Friend Sub CreateCompatableBitmaps(ByVal FormGraphics As Graphics)
        ' Insures all bitmaps are compatable with Display device
        Dim src As Rectangle = New Rectangle(0, 0, ICON.Width, ICON.Height)
        Dim dst As Rectangle = src
        Dim grx As Graphics

        myCityMap = New Bitmap(myCityRect.Width, myCityRect.Height, FormGraphics)
        grxCityMap = Graphics.FromImage(myCityMap)
        grxCityMap.InterpolationMode = Drawing2D.InterpolationMode.NearestNeighbor

        ConvertMap(myCars, FormGraphics)
        ConvertMap(myPrizes, FormGraphics)
        ConvertMap(myRoadMaps, FormGraphics)

        For i As Integer = 0 To 7
            myIcons(i) = New Bitmap(ICON.Width, ICON.Height, FormGraphics)
        Next

        grx = Graphics.FromImage(myIcons(Img.Home))
        grx.DrawImage(myPrizes, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

        grx = Graphics.FromImage(myIcons(Img.Fuel))
        src.X = 28
        grx.DrawImage(myPrizes, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

        grx = Graphics.FromImage(myIcons(Img.Gold))
        src.X = 28
        src.Y = 28
        grx.DrawImage(myPrizes, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

        grx = Graphics.FromImage(myIcons(Img.Cash))
        src.X = 0
        grx.DrawImage(myPrizes, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

        grx = Graphics.FromImage(myIcons(Img.Life))
        src.Y = 56
        grx.DrawImage(myPrizes, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

        grx = Graphics.FromImage(myIcons(Img.Life + 1))
        src.X = 28
        grx.DrawImage(myPrizes, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

        grx = Graphics.FromImage(myIcons(Img.Life + 2))
        src.X = 0
        src.Y = 84
        grx.DrawImage(myPrizes, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

        grx = Graphics.FromImage(myIcons(Img.Life + 3))
        src.X = 28
        grx.DrawImage(myPrizes, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

    End Sub

    Friend Sub NewMap(ByVal Index As Integer)
        ' Scale up map from Maps.bmp to CityMap
        myMapRect.Y = (Index * 86)  ' Hard coded due to space re-use in bitmap
        grxCityMap.DrawImage(myRoadMaps, myCityRect, myMapRect, GraphicsUnit.Pixel)
        ' Start with empty intersections
        ReDim myRoad(12, 14)
        ' Find available directions at all intersections
        ' (Avoids doing it during play)
        Dim vlu, px, py As Integer
        For y As Integer = 0 To 14
            For x As Integer = 0 To 12
                px = x * CELL_INTERVAL + EDGE_OFFSET.X
                py = y * CELL_INTERVAL + EDGE_OFFSET.Y
                vlu = 0
                If myCityMap.GetPixel(px, py).ToArgb = Color.Black.ToArgb Then
                    'myCityMap.SetPixel(px - 2, py - 2, Color.White)
                    If myCityMap.GetPixel(px - 1, py).ToArgb = Color.Black.ToArgb Then vlu = vlu Or TravelDirection.West
                    If myCityMap.GetPixel(px + 32, py).ToArgb = Color.Black.ToArgb Then vlu = vlu Or TravelDirection.East
                    If myCityMap.GetPixel(px, py - 1).ToArgb = Color.Black.ToArgb Then vlu = vlu Or TravelDirection.North
                    If myCityMap.GetPixel(px, py + 32).ToArgb = Color.Black.ToArgb Then vlu = vlu Or TravelDirection.South
                End If
                myRoad(x, y) = vlu
            Next
        Next
    End Sub

    Friend Sub GetIcons(ByRef Car As Bitmap, ByRef Gold As Bitmap, ByRef Van As Bitmap)
        ' Display needs to cache these images for its Updates
        Dim grx As Graphics
        Dim dst As Rectangle = New Rectangle(0, 0, ICON.Width, ICON.Height)
        Dim src As Rectangle = New Rectangle(0, 0, ICON.Width, ICON.Height)

        grx = Graphics.FromImage(Van)
        grx.DrawImage(myCars, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

        grx = Graphics.FromImage(Car)
        src.Y = ICON.Height * 2
        grx.DrawImage(myCars, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

        grx = Graphics.FromImage(Gold)
        src.Y = ICON.Height
        src.X = ICON.Width
        grx.DrawImage(myPrizes, dst, src, GraphicsUnit.Pixel)
        grx.Dispose()

    End Sub

    Friend Function Cell(ByVal Location As Point) As Integer
        ' Redirects to other routine 
        Return Cell(Location.X, Location.Y)
    End Function

    Friend Function Cell(ByVal X As Integer, ByVal Y As Integer) As Integer
        Return myRoad((X - EDGE_OFFSET.X) \ CELL_INTERVAL, (Y - EDGE_OFFSET.Y) \ CELL_INTERVAL)
    End Function

    Friend Function CityMap() As Bitmap
        Return myCityMap
    End Function

    Friend Function MapGraphics() As Graphics
        Return grxCityMap
    End Function

    Friend Function Mobile() As Bitmap
        Return myCars
    End Function

   'Friend Function Prizes() As Bitmap
   '   Return Nothing
   'End Function

    Friend Function Vacant() As Point
        ' Picks an open intersection and returns map coordinates
        Dim x, y As Integer
        Do

            x = myGenerator.Next(0, 12)
            y = myGenerator.Next(0, 14)

        Loop While ((myRoad(x, y) And TravelDirection.AnyRoad) = 0) _
            OrElse ((myRoad(x, y) And RoadObject.AnyItem) <> 0)

        Return New Point(x * CELL_INTERVAL + EDGE_OFFSET.X, _
                         y * CELL_INTERVAL + EDGE_OFFSET.Y)

    End Function

    Friend Sub Insert(ByVal Item As RoadObject, ByVal Location As Point)
        ' Redirects to other Insert routine 
        Insert(Item, Location.X, Location.Y)
    End Sub

    Friend Sub Insert(ByVal Item As RoadObject, ByVal X As Integer, ByVal Y As Integer)
        ' Adds an item to the Road (intersections) and redraws the cell 
        Dim cx As Integer = (X - EDGE_OFFSET.X) \ CELL_INTERVAL
        Dim cy As Integer = (Y - EDGE_OFFSET.Y) \ CELL_INTERVAL
        myRoad(cx, cy) = myRoad(cx, cy) Or Item
        DrawCell(cx, cy)
    End Sub

    Friend Sub Remove(ByVal Item As RoadObject, ByVal Location As Point)
        Remove(Item, Location.X, Location.Y)
    End Sub

    Friend Sub Remove(ByVal Item As RoadObject, ByVal X As Integer, ByVal Y As Integer)
        ' Removes an item from the Road (intersections) and redraws the cell 
        Dim cx As Integer = (X - EDGE_OFFSET.X) \ CELL_INTERVAL
        Dim cy As Integer = (Y - EDGE_OFFSET.Y) \ CELL_INTERVAL
        myRoad(cx, cy) = myRoad(cx, cy) And Not Item
        DrawCell(cx, cy)
    End Sub

    Friend Sub RefreshArea(ByRef Player As Sprite)
        Dim cx As Integer = (Player.Location.X - EDGE_OFFSET.X) \ CELL_INTERVAL
        Dim cy As Integer = (Player.Location.Y - EDGE_OFFSET.Y) \ CELL_INTERVAL
        If cy < 2 Then cy = 2
        If cy > 12 Then cy = 12
        If cx < 2 Then cx = 2
        If cx > 10 Then cx = 10
        For y As Integer = cy - 2 To cy + 2
            For x As Integer = cx - 2 To cx + 2
                If myRoad(x, y) > 0 Then DrawCell(x, y)
            Next
        Next
    End Sub


    Private Sub DrawCell(ByVal CX As Integer, ByVal CY As Integer)
        ' Draws the cells contents to the CityMap map
        Dim vlu As Integer = myRoad(CX, CY)

        If vlu > 0 Then
            myIconRect.X = (CX * CELL_INTERVAL) + EDGE_OFFSET.X + 2
            myIconRect.Y = (CY * CELL_INTERVAL) + EDGE_OFFSET.Y + 2

            If CBool(vlu And RoadObject.Cash) Then
                grxCityMap.DrawImageUnscaled(myIcons(Img.Cash), myIconRect)
            ElseIf CBool(vlu And RoadObject.Gold) Then
                grxCityMap.DrawImageUnscaled(myIcons(Img.Gold), myIconRect)
            ElseIf CBool(vlu And RoadObject.Home) Then
                grxCityMap.DrawImageUnscaled(myIcons(Img.Home), myIconRect)
            ElseIf CBool(vlu And RoadObject.Fuel) Then
                grxCityMap.DrawImageUnscaled(myIcons(Img.Fuel), myIconRect)
            ElseIf CBool(vlu And RoadObject.Life) Then
                grxCityMap.DrawImageUnscaled(myIcons(Img.Life), myIconRect)
            Else
                ' Remove
                grxCityMap.FillRectangle(Brushes.Black, myIconRect)
            End If
        End If

    End Sub


    Friend Sub Dispose() Implements IDisposable.Dispose
        If Not myCars Is Nothing Then myCars.Dispose()
        If Not myCars Is Nothing Then myCars.Dispose()
        If Not myRoadMaps Is Nothing Then myRoadMaps.Dispose()
      If Not myCityMap Is Nothing Then myCityMap.Dispose()
      If Not grxCityMap Is Nothing Then grxCityMap.Dispose()
    End Sub



   Public Shared Sub ConvertMap(ByRef Convert As Bitmap, ByRef FormGraphics As Graphics)
      Dim tmp As Bitmap
      Dim grx As Graphics
      tmp = New Bitmap(Convert.Width, Convert.Height, FormGraphics)
      grx = Graphics.FromImage(tmp)
      grx.DrawImage(Convert, 0, 0, Convert.Width, Convert.Height)
      Convert.Dispose()
      Convert = tmp
   End Sub

End Class
