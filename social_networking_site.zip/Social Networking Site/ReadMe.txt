Title: Social Networking Site
Description: This is a social networking site for beginners.it uses access database connectivity.it has facility of shout box,individual chat,topic discussion,exam practice,image sharing,image uploading,user profiles,result search,etc.If you like my code plz do vote for me..

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
