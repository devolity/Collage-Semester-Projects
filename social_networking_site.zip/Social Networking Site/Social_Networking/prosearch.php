<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
?>
<html>
<head>
<title>SEARCH PROFILE</title>
</head>
<body>
<h1 align="center"><font color="#800080" size="7">PROFILE SEARCH</font></h1>
<form action="profile.php" method="post">
<p align="center">
<b><font size="4" color="#FF33CC">Username:-</font></b><font color="#00FF00" size="4"><input name="user" size=24 style="font-weight: 700"></font></p>
<p align="center">
&nbsp;<input type="submit" value="Search" style="font-weight: 700">
</p>
</form>
</body>
</html>