<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
?>
<html>
<head>
<title>BCA RESULT</title>
</head>
<body>
&nbsp;<center>
<h2><font color="#FF00FF" size="7" onmouseover=" color='green'" onmouseout="color='#FF00FF'">Welcome Administrator!!!!</font></h2>
<p>&nbsp;</p>
<ul>
	<li><b><a href="AdminUsers.php" onmouseover="window.status='Users Login Info';return true;" onmouseout="window.status='**Administrator Mode**'"><font size="5">Login Info</font></a><font size="5">
	</font></b></li>
	<li><b><a href="AdminResult.php" onmouseover="window.status='Users Result Info';return true;" onmouseout="window.status='**Administrator Mode**'"><font size="5">Result Info</font></a><font size="5">
	</font></b></li>
	<li><b><a href="AdminQuestion.php" onmouseover="window.status='Exam Questions';return true;" onmouseout="window.status='**Administrator Mode**'"><font size="5">Exam Questions</font></a><font size="5">
	</font></b></li>
	<li><b><a href="deletechat.php" onmouseover="window.status='Delete Chat Content';return true;" onmouseout="window.status='**Administrator Mode**'"><font size="5">Delete Chat Content</font></a><font size="5">
	</font></b></li>
	<li><b><a href="delimg.php" onmouseover="window.status='Delete Uploaded Images';return true;" onmouseout="window.status='**Administrator Mode**'"><font size="5">Delete Uploaded Images</font></a><font size="5">
	</font></b></li>
	<li><b><a href="logout.php" onmouseover="window.status='Logout';return true;" onmouseout="window.status='**Administrator Mode**'"><font size="5">Logout</font></a><font size="5">
	</font></b></li>
</ul>
</body>
</html>