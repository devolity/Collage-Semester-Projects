<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
$loc="upload/".$_FILES["file"]["name"];
$uname=$_SESSION["unm"];
$imgname=$_FILES["file"]["name"];
if(($_FILES["file"]["type"]=="image/gif") || ($_FILES["file"]["type"]=="image/jpeg") || ($_FILES["file"]["type"]=="image/pjpeg"))
{
	if($_FILES["file"]["error"] > 0)
		echo "error code:" . $_FILES["file"]["error"]."<br>";
	else
	{
		if(file_exists($loc))
			echo "<font color='red'><h2>The File you are trying to upload already exists</h2>";
		else
		{
			move_uploaded_file($_FILES["file"]["tmp_name"],$loc);
			$con=odbc_connect('images','','');
			if(!$con)
				echo "connection not established";
			else
			{
				$qry="INSERT INTO images values('$loc','$imgname','$uname')";
				$rs=odbc_exec($con,$qry);
				if(!$rs)
					echo "database insertion of images failed";
				echo "<font color='blue'><h2>Your Image with the Name:-".$_FILES["file"]["name"]." and of size:=".($_FILES["file"]["size"]/1024)." KB has been Successfully Uploaded!!</h2>";
			}
		}
	}
}
else
	echo "<font color='red'><h2>Invalid Image Format.</h2>";

?>