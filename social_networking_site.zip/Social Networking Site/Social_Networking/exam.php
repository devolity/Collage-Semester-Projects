<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');

echo "<html>";
echo "<head>";
echo "<title>BCA RESULT</title>";
echo "</head>";
echo "<body>";
echo "<center>";

echo "<font color='#FFFFFF'>";
echo "<marquee bgcolor='#FF0000'><h1>BCA RESULT SEARCH</h1></marquee></font>";
echo "<table bgcolor='lightgreen' width=984 height=10>";
echo "<tr>";
echo "<td>";
echo "<b><font color='red' size=5>Welcome," . $_SESSION["unm"] ;
echo "</td><td><a href='chatbox.php'>CHAT ARENA</a></td><td><a href='chatuser.php'>Individual Chat</a></td><td><a href='mailwin.php'>E-Mail</a></td><td><a href='imgup.php'>Share Images</a></td><td><a href='quest.php'>Exam Practice</a></td><td><a href='prosearch.php'>Profile</a></td><td><a href='forum.php'>Forum</a></td><td><a href='logout.php'>Logout</a></td></table><br></b></font>";
echo "<form name='form1' action='GetResult.php' method='post'>";
echo "<font color='#000080'><b>Seat No.</b></font> <select name='code' size=1>";
echo "<option value='A'>A</option>";
echo "<option value='B'>B</option>";
echo "<option value='C'>C</option>";
echo "<option value='D'>D</option>";
echo "</select>";
echo "<input type='number' size=10 name='roll'>";
echo "<br>";
echo "<input type='submit' value='Result'>";
echo "</form>";
echo "<hr color='#808000'>";
echo "<a href='namesrch.php'>Forgot the Seat No.?Search By Name</a>";
echo "<hr color='#808000'>";
echo "<p>&nbsp;</p>";
echo "<p><b><font size='4' color='#3366FF'>This website is a sole proprietary of ";
echo "Husain Limdiyawala(SYBCA MSU).Any duplication of this website should be avoided.</font></b></p>";
echo "<p align='center'><font size='6' color='#FF0000'><b>&quot;MESS WITH THE BEST </b>";
echo "</font></p>";
echo "<p align='center'><font size='6' color='#FF0000'><b>DIE LIKE THE REST&quot;</b></font></p>";
echo "</body>";
echo "</html>";



?>
