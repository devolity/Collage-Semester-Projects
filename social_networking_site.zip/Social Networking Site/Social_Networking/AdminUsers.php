<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
?>

<html>
<head>
<title>BCA RESULT</title>
</head>
<body>
<center>
<h1><font color="#FF00FF">Password Info</font></h1>
<form name="form1" action="AdminUserswin.php" method="post">
<p><b><font color="#000080">Username:</font></b><input name="user" size=15 style="font-weight: 700"><b>
<br>
</b>
<font color="#000080"><b>Password:</b></font><b> </b> 
<input type="password" name="pas" size=15 style="font-weight: 700"><b>
<br>
</b>
<input type="submit" name="bt" value="Show" style="font-weight: 700"><b> </b>

<input type="submit"  name="bt" value="Add" style="font-weight: 700"><b> </b>

<input type="submit" name="bt" value="Delete" style="font-weight: 700"><b> </b>

<input type="submit" name="bt" value="Edit" style="font-weight: 700"><b> </b>
</p>
</form>
<p>&nbsp;</p>
</body>
</html>