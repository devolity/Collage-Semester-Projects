<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
$con=odbc_connect('questans','','');
if(!$con)
echo "not connected to database";
else
{
	if($_POST["bt"]=="Show")
	{
$ans=$_POST["answer"];
$qry="select * from questans where answer='" . $ans . "'";
$rs=odbc_exec($con,$qry);
if(!$rs)
echo "no result found";
else
{
	if(odbc_fetch_row($rs))
	{
		
		$questi=odbc_result($rs,1);
		$opt1i=odbc_result($rs,2);
		$opt2i=odbc_result($rs,3);
		$opt3i=odbc_result($rs,4);
		$opt4i=odbc_result($rs,5);
		$ansi=odbc_result($rs,6);
	echo "<html><head><title>BCA QUESTIONS</title></head><body>";
	echo "<table border=2 bgcolor='lightblue' height=600 width=600><tr>";
	echo "<td><b><font color='maroon' size=4>Question:-</td><td>" . $questi . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Option 1:-</td><td>" . $opt1i . "<tr>";
	echo "<td><b><font color='maroon' size=4>Option 2:-</td><td>" . $opt2i . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Option 3:-</td><td>" . $opt3i . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Option 4:-</td><td>" . $opt4i . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Answer:-</td><td>" . $ansi . "</td><tr>";
	echo "</table></b>";
	echo "</body></html>";	
	}
	else
	{
		echo "no records found";
	}
}
}
if($_POST["bt"]=="Add")
{
		$quest=$_POST["quest"];
		$opt1=$_POST["option1"];
		$opt2=$_POST["option2"];
		$opt3=$_POST["option3"];
		$opt4=$_POST["option4"];
		$answ=$_POST["answer"];
	$con=odbc_connect('questans','','');
	$qry="insert into questans values('$quest','$opt1','$opt2','$opt3','$opt4','$answ')";
	
	$rs=odbc_exec($con,$qry) or die(odbc_errormsg());
	if($rs)
	echo "Record successfully added in the database";
	else
	echo "Record addition failed!!!";
}

if($_POST["bt"]=="Edit")
{
	
		$quest=$_POST["quest"];
		$opt1=$_POST["option1"];
		$opt2=$_POST["option2"];
		$opt3=$_POST["option3"];
		$opt4=$_POST["option4"];
		$answ=$_POST["answer"];
	$con=odbc_connect('questans','','');
	$qry="UPDATE questans set question='$quest',option1='$opt1',option2='$opt2',option3='$opt3',option4='$opt4' where answer='$answ'";
	$rs=odbc_exec($con,$qry) or die(odbc_errormsg());
	if($rs)
	echo "Record successfully Edited in the database";
	else
	echo "Record Editing failed!!!";
}

if($_POST["bt"]=="Delete")
{
		
	$answ=$_POST["answer"];
	$con=odbc_connect('questans','','');
	$qry="DELETE from questans "." where answer='".$answ."'";
	$rs=odbc_do($con,$qry);
	if($rs)
	echo "Record successfully Deleted from the database";
	else
	echo "Record Deletion failed!!!";
}











}
?>

  



	
