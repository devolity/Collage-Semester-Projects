<?php
header("Cache-Control","no-cache");
session_start();
$con=odbc_connect('logininfo','','');
if(!$con)
	echo "no connection found";
$uname=$_SESSION["unm"];
$qry="delete from logged where logged='$uname'";
echo $uname;
$rs=odbc_exec($con,$qry);
if(!$rs)
	echo "record deletion failed";
$flnm=$_SESSION["chatfile"];
unlink($flnm);
session_unregister("id");
session_unregister("unm");
session_unset();
session_destroy();
header('location:index.html');
?>