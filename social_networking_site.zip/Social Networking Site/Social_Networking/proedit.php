<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
$con=odbc_connect('logininfo','','');
if(!$con)
	echo "not connected";

$favsong=$_POST["S1"];
$favmovie=$_POST["S2"];
$favartist=$_POST["S3"];
$favactor=$_POST["S4"];
$uname=$_SESSION["unm"];
$qry="update logininfo set favsongs='$favsong',favmovies='$favmovie',favartist='$favartist',favactors='$favactor' where username='$uname'";
$rs=odbc_exec($con,$qry);
if(!$rs)
echo "no records found";
else
{
echo "<h2><font color='blue'>Your Profile has been Successfully Edited!!!</font></h2>";
echo "<center>";
echo "<br>";
echo "<a href='redirect.php'>Go To Home Page</a>";
echo "</center>";
echo "</body>";
echo "</html>";
}
?>