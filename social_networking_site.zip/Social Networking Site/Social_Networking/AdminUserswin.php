<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
$uname=$_POST["user"];
$pass=$_POST["pas"];
$con=odbc_connect('logininfo','','');
if(!$con)
echo "not connected to database";
else
{
	if($_POST["bt"]=="Show")
	{
$qry="select * from logininfo where username='" . $uname . "'";
$rs=odbc_exec($con,$qry);
if(!$rs)
echo "no result found";
else
{
	if(odbc_fetch_row($rs))
	{
		$pass=odbc_result($rs,2);
		

	echo "<html><head><title>BCA USERS</title></head><body>";
	echo "<table border=2 bgcolor='lightblue' height=600 width=600><tr>";
	echo "<td><b><font color='maroon' size=4>Name of User:-</td><td>" . $uname . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Password:-</td><td>" . $pass . "<tr>";
	echo "</table></b>";
	echo "</body></html>";	
	}
	else
	{
		echo "no records found";
	}
}
}
if($_POST["bt"]=="Add")
{
	$user=$_POST["user"];
	$pass=$_POST["pas"];
	$con=odbc_connect('logininfo','','');
	$qry="insert into logininfo (username,password) values('$user','$pass')";
	
	$rs=odbc_exec($con,$qry) or die(odbc_errormsg());
	if($rs)
	echo "Record successfully added in the database";
	else
	echo "Record addition failed!!!";
}

if($_POST["bt"]=="Edit")
{
	$user=$_POST["user"];
	$pass=$_POST["pas"];
	$con=odbc_connect('logininfo','','');
	$qry="UPDATE logininfo set password='$pass' where username='$user'";
	$rs=odbc_exec($con,$qry) or die(odbc_errormsg());
	if($rs)
	echo "Record successfully Edited in the database";
	else
	echo "Record Editing failed!!!";
}

if($_POST["bt"]=="Delete")
{	
	$user=$_POST["user"];
	$pass=$_POST["pas"];
	$con=odbc_connect('logininfo','','');
	$qry="DELETE from logininfo where username='$user' and password='$pass'";
	$rs=odbc_do($con,$qry);
	if($rs)
	echo "Record successfully Deleted from the database";
	else
	echo "Record Deletion failed!!!";
}











}
?>

  



	
