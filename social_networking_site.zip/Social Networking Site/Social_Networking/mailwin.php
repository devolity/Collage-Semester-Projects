<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
?>

<html>
<head>
</head>
<body bgcolor="#FFCCFF">
<center>
<h1><font color="#800000">Whosane's E-Mail Sender</font></h1>
<form name="form1" method="post" action="mail.php">
<p align="left"><b><font color="#800000" size="4">TO:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></b>&nbsp;<input type="text" name="to" size=30>
<br>
<b><font size="4" color="#800000">From:&nbsp;&nbsp;&nbsp;&nbsp; </font></b>   <input type="text" name="from" size=30>
<br>
<b><font size="4" color="#800000">Subject:&nbsp; </font></b><input type="text" name="sub" size=50>
<br>
<b><font size="4" color="#800000">Message:</font></b><textarea name="msg" rows=19 cols=43></textarea>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="btn" value="Send">
</p>
</form>
<h3><font color="#800000">*Enter the Gmail Address of the recipient and any desired sender address to send the mail</font></h3>
</body>
</html>


