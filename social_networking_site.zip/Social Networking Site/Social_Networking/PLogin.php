<?php
session_start();

if(!isset($_SESSION['id']))
header('location: index.html');

$uname=$_POST["uname"];
$pass=$_POST["pass"];

$con=odbc_connect('logininfo','','');
if(!$con)
echo "no connection established";

$qry="select * from logininfo where username='" . $uname . "' and password='" . $pass . "'";
$rs=odbc_exec($con,$qry);
if(!rs)
echo "no recordset found";
else
{
	if(odbc_fetch_row($rs))
	{
		$_SESSION['id']=session_id();
		$_SESSION['unm']=$uname;
		$myuser=odbc_result($rs,1);
		if($myuser=="administrator")
		header('location: Admin.php');
		else
		{
			$qry="insert into logged values('$uname')";
			$rs=odbc_exec($con,$qry);
			if(!$rs)
				echo "error recording users";
			header('location: exam.php');
		}

	}
	else
	{
		header('location:nofound.html');
	}
}		
?>
