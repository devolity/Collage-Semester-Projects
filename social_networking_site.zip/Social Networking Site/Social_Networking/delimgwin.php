<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
$flt=$_POST["delimg"];
if(@unlink("upload/".$flt))
{
$con=odbc_connect('images','','');
$qry="DELETE FROM images where imgname='$flt'";
$rs=odbc_exec($con,$qry);
echo "<font color='green'><h1>Image successfully deleted!!!</h1></font>";
}
else
echo "<font color='red'><h1>No Such Image Exists!!!</h1></font>";
?>