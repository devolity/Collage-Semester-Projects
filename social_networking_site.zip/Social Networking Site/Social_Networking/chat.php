<html>
<head>
<meta http-equiv="refresh" content="5">
</head>
<body>
<?php include "chat.dat";?>
</body>
</html>