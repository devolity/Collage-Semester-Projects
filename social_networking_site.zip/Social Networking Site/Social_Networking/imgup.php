<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
?>
<html>
<head>
<title>SHARE IMAGE</title>
</head>
<body bgcolor="pink">
<b><font color="maroon">
<center>
<marquee bgcolor="yellow"><h1>Whosane's Image Zone</h1></marquee>
<form name="form1" action="uploadimg.php" method="post" enctype="multipart/form-data">
FileName:<input type="file" name="file" id="file">
<br>
<input type="submit" name="submit" value="Upload Image">
</form>
<br>
<a href="imggal.php">Image Gallery</a></center>
</font>
</body>
<html>