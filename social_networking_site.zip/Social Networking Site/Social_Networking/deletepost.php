<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
$msg=$_POST["delpost"];
$con=odbc_connect('logininfo','','');
$qry="delete from forum where comment='$msg'";
$rs=odbc_exec($con,$qry);
if(!$rs)
	echo "no record deleted";
header('location:forum.php');
?>