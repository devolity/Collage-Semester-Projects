<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
echo "<html>";
echo "<head><title>BCA FORUM</title></head>";
echo "<body>";
echo "<font color='maroon'><center><h1>BCA Board</h1></center><table border=1 bgcolor='lightgreen' height=600 width=900>";
echo "<th>Comment</th><th>Author</th><th>DisplayPic</th>";

$con=odbc_connect('logininfo','','');
if(!$con)
	echo "not connected";
$qry="select * from forum";
$rs=odbc_exec($con,$qry);
$uname=$_SESSION["unm"];
while(odbc_fetch_row($rs))
{
	echo "<tr>";
	$dis=odbc_result($rs,3);
	if($dis=="")
		$dis="displaypic/anonymous.jpg";
	echo "<td width='500'>".odbc_result($rs,2)."</td><td>".odbc_result($rs,1)."</td><td><img src='$dis' width=100 height=100></td>";
	if($uname==odbc_result($rs,1))
	echo "<td><form action='deletepost.php' method='post'><input type='hidden' name='delpost' value='".odbc_result($rs,2)."'><input type='submit' value='Delete'></form></td>";
}
echo "</table>";
echo "<center><form name='myform' action='addpost.php' method='post'><textarea rows='5' cols='40' name='msg'></textarea><br><input type='submit' value='Discuss'></form></center>";
echo "<br>";
echo "<center>";
echo "<a href='redirect.php'>Go To Home Page</a>";
echo "</center>";
echo "</body>";
?>