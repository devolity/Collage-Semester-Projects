<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
echo "<html>";
echo "<head>";
echo "<title>BCA RESULT</title>";
echo "</head>";
echo "<body>";
echo "<center>";
echo "<b>";
echo "<font color='#FFFFFF'>";
echo "<marquee bgcolor='#008080'><h1>SEARCH RESULT BY NAME</h1></marquee></font>";
echo "</b><hr>";
echo "<form name='form1' action='GetResultByName.php' method='post'>";
echo "<font color='#000080'><b>Name:</b></font><input size=20 name='uname' style='font-weight: 700'><b>";
echo "<br>";
echo "</b>";
echo "<input type='submit' value='Search' style='font-weight: 700'><b> </b>";
echo "</form>";
echo "<hr>&nbsp;";
echo "</body>";
echo "</html>";

?>