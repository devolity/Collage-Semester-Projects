<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
?>
<html>
<head>
<title>Delete Photos</title>
</head>
<body>
<center><b>
<p align="center"><b><font size="6" color="#800080">Enter the Name of the image 
you want to delete:-</font></b></p>
<br>
<form action="delimgwin.php" method="post">
<input type="text" name="delimg" size=30>
<br>
<input type="submit" value="delete">
</form>
</center>
</b>
</body>
</html>