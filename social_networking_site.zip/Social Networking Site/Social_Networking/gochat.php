<?php 
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
$chtflnm=$_POST["chatuser"];
$uname=$_SESSION["unm"];
$chtflnm1="chat/".$chtflnm.$uname.".dat";
$chtflnm2="chat/".$uname.$chtflnm.".dat";

$finalfl="";
if(file_exists($chtflnm1))
$finalfl=$chtflnm1;

if(file_exists($chtflnm2))
$finalfl=$chtflnm2;

if((!file_exists($chtflnm1)) && (!file_exists($chtflnm2)))
$finalfl=$chtflnm1;
fopen($finalfl,"a+");
$_SESSION["chatfile"]=$finalfl;
header('location:chatboxindi.php');
?>


