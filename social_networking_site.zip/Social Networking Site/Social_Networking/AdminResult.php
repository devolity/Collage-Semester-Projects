<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
?>
<html>
<head>
<title>BCA RESULT</title>
</head>
<body>
<font color="#000080"><b>
<script language="javascript">
function check()
{
	if(isNaN(form1.roll.value))
	{
		alert("Please Enter a Number");
		form1.roll.value = "";
	}
	if(isNaN(form1.myjava.value))
	{
		alert("Please Enter a Number");
		form1.myjava.value = "";
	}
	if(isNaN(form1.netw.value))
	{
		alert("Please Enter a Number");
		form1.netw.value = "";
	}
	if(isNaN(form1.webtech.value))
	{
		alert("Please Enter a Number");
		form1.webtech.value = "";
	}
	if(isNaN(form1.stats.value))
	{
		alert("Please Enter a Number");
		form1.stats.value = "";
	}
	if(isNaN(form1.se.value))
	{
		alert("Please Enter a Number");
		form1.se.value = "";
	}
	if(isNaN(form1.prac1.value))
	{
		alert("Please Enter a Number");
		form1.prac1.value = "";
	}
	if(isNaN(form1.prac2.value))
	{
		alert("Please Enter a Number");
		form1.prac2.value = "";
	}
	if(isNaN(form1.prac3.value))
	{
		alert("Please Enter a Number");
		form1.prac3.value = "";
	}
}


</script>
</b></font>
<center>
<h2><font color="#FF00FF" size="6">Result Updater</font></h2>
<pre>
<form name="form1" action="AdminResultwin.php" method="post">
<font color="#000080"><b>ID                     :</b><select name="id" size=1 style="font-weight: 700"><option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option></select><b>
<br>
 Roll                   :</b><input name="roll" size=4 onchange="check()" style="font-weight: 700"><b>
<br>
 Name     :</b><input name="uname" size=20 onchange="check()" style="font-weight: 700"><b>
<br>
Java                   :</b><input type="number" name="java" size=3 onchange="check()" style="font-weight: 700"><b>
<br>
Network                :</b><input type="number" name="netw" size=3 onchange="check()" style="font-weight: 700"><b>
<br>
Web Tech               :</b><input type="number" name="webtech" size=3 onchange="check()" style="font-weight: 700"><b>
<br>
Statistics	       :</b><input type="number" name="stats" size=3 onchange="check()" style="font-weight: 700"><b>
<br>
Software Engg. 	       :</b><input type="number" name="se" size=3 onchange="check()" style="font-weight: 700"><b>
<br>
Practical(Java)        :</b><input type="number" name="prac1" size=3 onchange="check()" style="font-weight: 700"><b>
<br>
Practical(Web)         :</b><input type="number" name="prac2" size=3 onchange="check()" style="font-weight: 700"><b>
<br>
Practical(Net. & Stats):</b><input type="number" name="prac3" size=3 onchange="check()" style="font-weight: 700"><b>
<br>

</b>

<input type="submit" name="bt" value="Show" style="font-weight: 700"><input type="submit"  name="bt" value="Add" style="font-weight: 700"><input type="submit" name="bt" value="Delete" style="font-weight: 700"><input type="submit" name="bt" value="Edit" style="font-weight: 700"><b>
</b></font>
</form>
</pre>
</body>
</html>