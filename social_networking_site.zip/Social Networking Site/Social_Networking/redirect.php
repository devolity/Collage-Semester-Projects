<?php
header('location:exam.php');
?>