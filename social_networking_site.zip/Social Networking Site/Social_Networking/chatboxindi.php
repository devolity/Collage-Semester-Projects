<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
?>
<html>
<head>
<title>BCA CHAT</title>
</head>
<body bgcolor="pink">
<center>
<h1><font color="maroon">WHOSANE's CHAT BOX</h1>
<iframe src="chatindi.php" name="read" width="60%" height="40%"></iframe>
<br>
<form name="form1" method="post" action="writeindi.php" target="read">
Message:<input type="text" name="msg" size=80 onclick="msg.value=''">
<br>
<input type="submit" value="Chat">
</form>
<center>
<br>
<a href="redirect.php">Go To Home Page</a>
</center>
</body>
</html>