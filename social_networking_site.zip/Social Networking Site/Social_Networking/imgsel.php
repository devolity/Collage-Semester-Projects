<?php
session_start();
if ($_SESSION["id"] != session_id())
	header('location:index.html');
if(!isset($_SESSION["id"]))
	header('location:index.html');
$uname=$_SESSION["unm"];
$fl= "displaypic/" . $_FILES["file"]["name"];
$flname=$_FILES["file"]["name"];
if(($_FILES["file"]["type"]=="image/gif") || ($_FILES["file"]["type"]=="image/jpeg") || ($_FILES["file"]["type"]=="image/pjpeg"))
{
	if($_FILES["file"]["error"] > 0)
		echo "Error :" . $_FILES["file"]["error"] . "<br>";
	else
	{
		if(file_exists($flname))
			echo "<font color='red'><h2>The File you are trying to upload already exists</h2>";
			else
				{
				move_uploaded_file($_FILES["file"]["tmp_name"],$fl);
				$con=odbc_connect('logininfo','','');
				if(!$con)
					echo "not connected";
					$qry="select * from logininfo where username='$uname'";
					$rs=odbc_exec($con,$qry);
					$oldimg=odbc_result($rs,7);
					if($oldimg != "")
						unlink($oldimg);
					$qry="update logininfo set displaypic='$fl' where username='$uname'";
					$rs=odbc_exec($con,$qry);
					if(!$rs)
						echo "<font color='red'><h2>The Uploading of Image Failed</h2>";
					else
						echo "<font color='blue'><h2>Your Image with the Name:-".$_FILES["file"]["name"]." and of size:=".($_FILES["file"]["size"]/1024)." KB has been Successfully Uploaded!!</h2>";
				}
	}
}
else
	echo "<font color='red'><h2>Invalid Image Format.</h2>";

?>
	