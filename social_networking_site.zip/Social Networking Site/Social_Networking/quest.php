<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
$con=odbc_connect('questans','','');
$qry="select * from questans";
$rs=odbc_exec($con,$qry);
echo "<html>";
echo "<head>";
echo "<title>Exam Practice</title>";
echo "</head>";
echo "<body onload='timecnt()' onunload='timecntup()'>";
echo "<center><h1><font color='maroon'>Exam Practice</font></h1></center>";
echo "<script language='javascript'>";
echo "var i=0;";
echo "var timerid=null;";
echo "function timecnt()";
echo "{";
echo "i++;";
echo "document.form2.txtv.value = i + ' seconds';";
echo "timerid=setTimeout('timecnt()',1000);";
echo "}";
echo "function timecntup()";
echo "{";
echo "clearTimeout(timerid);";
echo "}";
echo "</script>";
echo "<form name='form2'>";
echo "<center>";
echo "Time Taken:<input type='text' name='txtv' size=10 disabled=true>";
echo "</form>";
echo "</center>";
echo "<table><tr>";
echo "<form name='form1' action='check.php' method='post'>";
 $i=0;
while(odbc_fetch_row($rs))
{
	
	$i++;
	echo "<td>".odbc_result($rs,1)."<td><select name='opt".$i."' size=1><option value='".odbc_result($rs,2)."'>".odbc_result($rs,2)."</option>";
	echo "<option value='".odbc_result($rs,3)."'>".odbc_result($rs,3)."</option>";
	echo "<option value='".odbc_result($rs,4)."'>".odbc_result($rs,4)."</option>";
	echo "<option value='".odbc_result($rs,5)."'>".odbc_result($rs,5)."</option></td><tr>";
		
	
}

	$_SESSION["count"]=$i;	
	echo "<td><center><input type='submit' value='answer'></td>";
	echo "</form></table></body></html>";


?>	



