<?php
unlink("chat.dat");
$file=fopen("chat.dat","a+");
fclose($file);
echo "<font color='green'><h1>The Chat Contents Have been successfully deleted!!!</h1></font>";
?>