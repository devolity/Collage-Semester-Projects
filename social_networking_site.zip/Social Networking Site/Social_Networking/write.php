<?php
session_start();
$file="chat.dat";
$sourc=fopen($file,"a");
$name= $_SESSION['unm'];
$msg=$_POST["msg"];
if($name !="" && $msg !="")
fwrite($sourc,"<font color='blue' size=4>$name>></font>" . "$msg<hr>");
else
echo "no chat session found";
echo "<script>window.location='chat.php'</script>"
?>