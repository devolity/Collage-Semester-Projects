<?php


$to=$_POST["to"];
$from="From:".$_POST["from"];
$subj="Subject:".$_POST["sub"];
$msg=$_POST["msg"];
if(@mail($to,$subj,$msg,$from))
{
echo "</h1><font color='blue'>The E-Mail was sent successfully!!!</font></h1>";
}
else
{
echo "</h1><font color='red'>The E-Mail sending Failed!!!</font></h1>";
}
?>
