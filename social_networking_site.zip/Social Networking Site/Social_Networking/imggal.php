<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
$con=odbc_connect('images','','');
if(!$con)
	echo "The Connection has Failed!";
$qry="select * from images";
$rs=odbc_exec($con,$qry);
echo "<html><head><title>Image Gallery</title></head><body bgcolor='silver'><font color='brown'><marquee bgcolor='yellow'><h1>Whosane's Image Gallery</h1></marquee><table width='100%'>";
while(odbc_fetch_row($rs))
{
	echo "<tr><td><a href='".odbc_result($rs,1)."'>".odbc_result($rs,2)."</a></td><td align='right'><form action='profile.php' method='post'><input type='hidden' name='user' value='".odbc_result($rs,3)."'><input type='submit' value='Uploaded By:-".odbc_result($rs,3)."'></form></td><br>";
}

echo "</table>";	
echo "<center>";
echo "<br>";
echo "<a href='redirect.php'>Go To Home Page</a>";
echo "</center>";
echo "</body>";
echo "</html>";
?>