<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
$con=odbc_connect('logininfo','','');
$msg=$_POST["msg"];
if(!$con)
	echo "not connected";

$uname=$_SESSION["unm"];
$qry="select * from logininfo where username='$uname'";
$rs=odbc_exec($con,$qry);
if(!$rs)
	echo "record addition failed";
$displ=odbc_result($rs,7);
$qry="insert into forum values('$uname','$msg','$displ')";
$rs=odbc_exec($con,$qry);
if(!$rs)
	echo "record addition failed";
header('location:forum.php');
?>