<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
$dig=$_POST["id"];
$seat=$_POST["roll"];
$gd="honours";
$con=odbc_connect('Result','','');
if(!$con)
echo "not connected to database";
else
{
	if($_POST["bt"]=="Show")
	{
$qry="select * from Result where id='" . $dig . "' and roll=" . $seat;
$rs=odbc_exec($con,$qry);
if(!$rs)
echo "no result found";
else
{
	if(odbc_fetch_row($rs))
	{
		$java=odbc_result($rs,4);
		$network=odbc_result($rs,5);
		$webtech=odbc_result($rs,6);
		$stats=odbc_result($rs,7);
		$se=odbc_result($rs,8);
		$prac1=odbc_result($rs,9);
		$prac2=odbc_result($rs,10);
		$prac3=odbc_result($rs,11);
		$uname=odbc_result($rs,1);
		$tot=$java+$network+$webtech+$stats+$se+$prac1+$prac2+$prac3;
		
		$perc=$tot*100/800;

		if($perc>=90)
			$gd="Honours";
		else if($perc>=80)
			$gd="A+";
		else if($perc>=70)
			$gd="Distinction";
		else if($perc>=60)
			$gd="First Class";
		else if($perc>=50)
			$gd="Second Class";
		else if($perc>=40)
			$gd="Pass Class";
	echo "<html><head><title>BCA RESULT</title></head><body>";
	echo "<table border=2 bgcolor='lightblue' height=600 width=600><tr>";
	echo "<td><b><font color='maroon' size=4>Name of Student:-</td><td>" . $uname . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Java Programming:-</td><td>" . $java . "<tr>";
	echo "<td><b><font color='maroon' size=4>Networks:-</td><td>" . $network . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Webtech:-</td><td>" . $webtech . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Statistics:-</td><td>" . $stats . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Software Engineering:-</td><td>" . $se . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Practical 1:-</td><td>" . $prac1 . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Practical 2:-</td><td>" . $prac2 . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Practical 3:-</td><td>" . $prac3 . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Total Marks:-</td><td>" . $tot . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Percentage:-</td><td>" . $perc . "</td><tr>";
	echo "<td><b><font color='maroon' size=4>Grade:-</td><td>" . $gd . "</td><tr>";
	echo "</table></b>";
	echo "</body></html>";	
	}
	else
	{
		echo "no records found";
	}
}
}
if($_POST["bt"]=="Add")
{
	$id=$_POST["id"];
	$roll=$_POST["roll"];
	$uname=$_POST["uname"];
	$java=$_POST["java"];
	$netw=$_POST["netw"];
	$webtech=$_POST["webtech"];
	$stats=$_POST["stats"];
	$se=$_POST["se"];
	$prac1=$_POST["prac1"];
	$prac2=$_POST["prac2"];
	$prac3=$_POST["prac3"];
	$con=odbc_connect('Result','','');
	$qry="insert into Result values('$uname','$id',$roll,$java,$netw,$webtech,$stats,$se,$prac1,$prac2,$prac3)";
	
	$rs=odbc_exec($con,$qry) or die(odbc_errormsg());
	if($rs)
	echo "Record successfully added in the database";
	else
	echo "Record addition failed!!!";
}

if($_POST["bt"]=="Edit")
{
	$id=$_POST["id"];
	$roll=$_POST["roll"];
	$uname=$_POST["uname"];
	$java=$_POST["java"];
	$netw=$_POST["netw"];
	$webtech=$_POST["webtech"];
	$stats=$_POST["stats"];
	$se=$_POST["se"];
	$prac1=$_POST["prac1"];
	$prac2=$_POST["prac2"];
	$prac3=$_POST["prac3"];
	$con=odbc_connect('Result','','');
	$qry="UPDATE Result set name='".$uname."',java=".$java.",network=".$netw.",webtech=".$webtech.",stats=".$stats.",se=".$se.",prac1=".$prac1.",prac2=".$prac2.",prac3=".$prac3." where id='".$id."' and roll=".$roll;
	$rs=odbc_exec($con,$qry) or die(odbc_errormsg());
	if($rs)
	echo "Record successfully Edited in the database";
	else
	echo "Record Editing failed!!!";
}

if($_POST["bt"]=="Delete")
{
	$id=$_POST["id"];
	$roll=$_POST["roll"];
	$uname=$_POST["uname"];
	$java=$_POST["java"];
	$netw=$_POST["netw"];
	$webtech=$_POST["webtech"];
	$stats=$_POST["stats"];
	$se=$_POST["se"];
	$prac1=$_POST["prac1"];
	$prac2=$_POST["prac2"];
	$prac3=$_POST["prac3"];
	$con=odbc_connect('Result','','');
	$qry="DELETE from Result"." where id='".$id."' and roll=".$roll;
	$rs=odbc_do($con,$qry);
	if($rs)
	echo "Record successfully Deleted from the database";
	else
	echo "Record Deletion failed!!!";
}











}
?>

  



	
