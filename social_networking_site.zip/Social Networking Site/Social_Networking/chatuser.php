<?php 
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');
$con=odbc_connect('logininfo','','');
if(!$con)
	echo "not connected";
$qry="select * from logged";
$rs=odbc_exec($con,$qry);
if(!$rs)
	echo "no records found";
echo "<html><head><title>Select Chat User</title><meta http-equiv='refresh' content='5'></head><body><center><font color='maroon'><h2>Logged In Users</h2>";
echo "<form action='gochat.php' method='post'><select name='chatuser' size=1>";
while(odbc_fetch_row($rs))
{
echo "<option value='".odbc_result($rs,1)."'>".odbc_result($rs,1)."</option>";
}
echo "</select><center><br><input type='submit' value='Chat'></center><hr>";
echo "</form></body></html>";

?>