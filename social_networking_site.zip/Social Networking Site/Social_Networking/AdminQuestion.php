<?php
session_start();
if(!$_SESSION["id"]==session_id())
header('location:index.html');
if(!isset($_SESSION['id']))
header('location:index.html');
?>

<html>
<head>
<title>BCA RESULT</title>
</head>
<body>
<font color="#000080"><b>

</b></font>
<center>
<h2><font size="6" color="#FF00FF">Question Paper Updater</font></h2>
<pre>
<form name="form1" action="AdminQuest.php" method="post">

<br><b>
Question:</b><input type="text" name="quest" size=100 style="font-weight: 700"><b>
<br>
Option 1               :</b><input type="text" name="option1" size=15 style="font-weight: 700"><b>
<br>
Option 2               :</b><input type="text" name="option2" size=15 style="font-weight: 700"><b>
<br>
Option 3               :</b><input type="text" name="option3" size=15 style="font-weight: 700"><b>
<br>
Option 4               :</b><input type="text" name="option4" size=15 style="font-weight: 700"><b>
<br>
Answer*                :</b><input type="text" name="answer" size=15 style="font-weight: 700"><b>
<br>
</b>

<input type="submit" name="bt" value="Show" style="font-weight: 700"><input type="submit"  name="bt" value="Add" style="font-weight: 700"><input type="submit" name="bt" value="Delete" style="font-weight: 700"><input type="submit" name="bt" value="Edit" style="font-weight: 700"><b>
</b></font>
</form>
</pre>
</body>
</html>