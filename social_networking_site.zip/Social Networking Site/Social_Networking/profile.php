<?php
session_start();
if(!($_SESSION['id']==session_id()))
header('location:index.html');
if(!(isset($_SESSION['id'])))
header('location:index.html');

$con=odbc_connect('logininfo','','');
$uname=$_REQUEST["user"];
if(!$con)
	echo "not connected";


$qry="select * from logininfo where username='$uname'";
$rs=odbc_exec($con,$qry);
if(!$rs)
echo "no records found";
else
{
$name=odbc_result($rs,1);
$favsong=odbc_result($rs,3);
$favmovie=odbc_result($rs,4);
$favartist=odbc_result($rs,5);
$favactor=odbc_result($rs,6);
$imgs=odbc_result($rs,7);
if($imgs == "")
	$imgs="displaypic/anonymous.jpg";
echo "<html>";
echo "<head>";
echo "<meta http-equiv='Content-Language' content='en-us'>";
echo "<title>Favourite Songs</title>";
echo "</head>";
echo "<body>";
echo "<h1 align='center'><font color='#008080'>Profile:-($name)</font></h1>";
echo "<center><img src='$imgs' width=200 height=200></center>";
echo "<form action='proedit.php' method='post'>";
echo "<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<font color='#808000'><b>&nbsp;&nbsp; Favourite Songs:-</b></font></p>";
echo "<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "</b><textarea rows='4' name='S1' cols='66' style='font-weight: 700'>$favsong</textarea></p>";
echo "<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<font color='#808000'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Favourite Movies:-</font></b></p>";
echo "<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "</b><textarea rows='4' name='S2' cols='66' style='font-weight: 700'>$favmovie</textarea><b>&nbsp;";
echo "</b></p>";
echo "<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<font color='#808000'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; 
echo "Favourite Artist:-</font></b></p>";
echo "<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "</b><textarea rows='4' name='S3' cols='66' style='font-weight: 700'>$favartist</textarea></p>";
echo "<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<font color='#808000'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Favourite Actors:-</font></b></p>";
echo "<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "</b><textarea rows='4' name='S4' cols='66' style='font-weight: 700'>$favactor</textarea></p>";
if($_SESSION["unm"] == $uname)
{
echo "<center><input type='submit' name='btn' value='Edit'></center></form>";
echo "<form action='imgsel.php' method='post' enctype='multipart/form-data'>";
echo "<center>FileName:-<input type='file' name='file'><input type='submit' value='Upload DisplayImage'></center></form>";
}
echo "</body>";
echo "</html>";
}

?>