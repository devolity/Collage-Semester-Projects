﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using SensSMSBUsinessLogic;
using SendSMSBusinessLogic;
using SendSMSBusinessObject;
using SensSMSBusinessLogic;

public partial class Admin_SendSMS : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void SendSMS_Click(object sender, EventArgs e)
    {

        Button btn = sender as Button;
        string message = (btn.Parent.FindControl("txtMessage") as TextBox).Text;

        int groupId = int.Parse(btn.CommandArgument);
        Users users = GroupsXUsersBL.GetAllStudents(groupId);

        if (users == null)
            return;

        foreach (SendSMSBusinessObject.User user in users)
        {
            SendSMSBL.SendSMS(user.PhoneNo, message);
        }
    }

    protected void ShowMessageBox_Click(object sender, EventArgs e)
    {
        LinkButton btn = sender as LinkButton;
        Panel pnl = btn.Parent.FindControl("pnlSendSms") as Panel;
        pnl.Visible = true;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Button btn = sender as Button;
        Panel pnl = btn.Parent as Panel;
        pnl.Visible = false;
    }
}
