using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;


namespace Rating
{
	/// <summary>
	/// Summary description for Rate.
	/// </summary>
	public class Rate : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label lblRating;
		
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string p = "Select * from " + ConfigurationSettings.AppSettings["MyPhotos"] + " WHERE id = '" + Convert.ToInt32(Request.QueryString["id"]) + "'";
				
			clsDataAccess myDAR = new clsDataAccess();
			myDAR.openConnection(); 
			double myRatedBy = Convert.ToInt32(myDAR.getValue(p,Convert.ToInt32(ConfigurationSettings.AppSettings["RatedByField"])));
			double myScore = Convert.ToDouble(myDAR.getValue(p,Convert.ToInt32(ConfigurationSettings.AppSettings["ScoreField"])));
				
			double myCRating = Convert.ToDouble(Request.QueryString["Rating"]);
			double myTotalRating = (myScore + myCRating)/(myRatedBy+1);
		
			myDAR.closeConnection();


			double ORating = 0.0;

			if (myRatedBy>0)
				ORating = myScore/myRatedBy;
			
			string myTotalRatingString = "";

			if ((ORating <1)&&(ORating>0))
				myTotalRatingString = ".5";
			else if (ORating ==1.0)
				myTotalRatingString = "1";
			else if ((ORating >1)&&(ORating<2))
				myTotalRatingString = "1.5";
			else if (ORating ==2.0)
				myTotalRatingString = "2";
			else if ((ORating >2)&&(ORating<3))
				myTotalRatingString = "2.5";
			else if (ORating ==3.0)
				myTotalRatingString = "3";
			else if ((ORating >3)&&(ORating<4))
				myTotalRatingString = "3.5";
			else if (ORating ==4.0)
				myTotalRatingString = "4";
			else if ((ORating >4)&&(ORating<5))
				myTotalRatingString = "4.5";
			else if (ORating ==5.0)
				myTotalRatingString = "5";
			else if (ORating ==0.0)
				myTotalRatingString = "0";


			lblRating.Text  = "<IMG src='images/stars" + myTotalRatingString + ".gif'>" ;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.lblRating.Init += new System.EventHandler(this.lblRating_Init);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void lblRating_Init(object sender, System.EventArgs e)
		{
		
		}
	}
}
