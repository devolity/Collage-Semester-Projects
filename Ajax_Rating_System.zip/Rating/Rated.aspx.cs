using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration; 

namespace Rating
{
	/// <summary>
	/// Summary description for Rated.
	/// </summary>
	public class Rated : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label Label1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!IsPostBack)
			{

				
				if ((Convert.ToInt32(Request.QueryString["Rating"])==1)||(Convert.ToInt32(Request.QueryString["Rating"])==2)||(Convert.ToInt32(Request.QueryString["Rating"])==3)||(Convert.ToInt32(Request.QueryString["Rating"])==4)||(Convert.ToInt32(Request.QueryString["Rating"])==5))
				{
					Label1.Text = "<IMG src='images/" + Request.QueryString["rating"] + "star.gif'>" ;
					Label2.Text = "<IMG src='images/saved.gif'>" ;
				}
				else
				{
					Response.Redirect("Rate.aspx?id=" + Convert.ToInt32(Request.QueryString["id"]));
				}



				string p = "Select * from " + ConfigurationSettings.AppSettings["MyPhotos"] + " WHERE id = '" + Convert.ToInt32(Request.QueryString["id"]) + "'";
				
				clsDataAccess myDAR = new clsDataAccess();
				myDAR.openConnection(); 
				double myRatedBy = Convert.ToInt32(myDAR.getValue(p,Convert.ToInt32(ConfigurationSettings.AppSettings["RatedByField"])));
				double myScore = Convert.ToDouble(myDAR.getValue(p,Convert.ToInt32(ConfigurationSettings.AppSettings["ScoreField"])));
				

				double myCRating = Convert.ToDouble(Request.QueryString["Rating"]);

				double myTotalRating =0.0;
					
				if ((Convert.ToInt32(Request.QueryString["Rating"])==1)||(Convert.ToInt32(Request.QueryString["Rating"])==2)||(Convert.ToInt32(Request.QueryString["Rating"])==3)||(Convert.ToInt32(Request.QueryString["Rating"])==4)||(Convert.ToInt32(Request.QueryString["Rating"])==5))
					myTotalRating = (myScore + myCRating)/(myRatedBy+1);
				else
					myTotalRating = (myScore)/(myRatedBy);

				myDAR.closeConnection();

				string myTotalRatingString = "";

				if ((myTotalRating <1)&&(myTotalRating>0))
					myTotalRatingString = ".5";
				else if (myTotalRating ==1.0)
					myTotalRatingString = "1";
				else if ((myTotalRating >1)&&(myTotalRating<2))
					myTotalRatingString = "1.5";
				else if (myTotalRating ==2.0)
					myTotalRatingString = "2";
				else if ((myTotalRating >2)&&(myTotalRating<3))
					myTotalRatingString = "2.5";
				else if (myTotalRating ==3.0)
					myTotalRatingString = "3";
				else if ((myTotalRating >3)&&(myTotalRating<4))
					myTotalRatingString = "3.5";
				else if (myTotalRating ==4.0)
					myTotalRatingString = "4";
				else if ((myTotalRating >4)&&(myTotalRating<5))
					myTotalRatingString = "4.5";
				else if (myTotalRating ==5.0)
					myTotalRatingString = "5";
				


				Label3.Text  = "<IMG src='images/stars" + myTotalRatingString + ".gif'>" ;

				int RatedBy =0;
				int TRating =0;
				if ((Convert.ToInt32(Request.QueryString["Rating"])==1)||(Convert.ToInt32(Request.QueryString["Rating"])==2)||(Convert.ToInt32(Request.QueryString["Rating"])==3)||(Convert.ToInt32(Request.QueryString["Rating"])==4)||(Convert.ToInt32(Request.QueryString["Rating"])==5))
				{
					RatedBy = Convert.ToInt32(myRatedBy)+1;
					TRating = Convert.ToInt32(myScore)+Convert.ToInt32(Request.QueryString["rating"]);
				}
				else
				{
					RatedBy = Convert.ToInt32(myRatedBy);
					TRating = Convert.ToInt32(myScore);
				}

					string q = "UPDATE " + ConfigurationSettings.AppSettings["MyPhotos"] + " SET Score = '" + TRating + " ' , RatedBy = '" + RatedBy + "' WHERE id = '" + Convert.ToInt32(Request.QueryString["id"]) + "'";
				
					clsDataAccess myDA = new clsDataAccess();
					myDA.openConnection(); 
					myDA.saveData(q);
					myDA.closeConnection(); 

				if ((Convert.ToInt32(Request.QueryString["Rating"])==1)||(Convert.ToInt32(Request.QueryString["Rating"])==2)||(Convert.ToInt32(Request.QueryString["Rating"])==3)||(Convert.ToInt32(Request.QueryString["Rating"])==4)||(Convert.ToInt32(Request.QueryString["Rating"])==5))
				{
					Response.Cookies["RatedAmz" + Convert.ToInt32(Request.QueryString["id"])].Value = Request.QueryString["Rating"].ToString();
				}
				

			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Label2.Init += new System.EventHandler(this.Label2_Init);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Label2_Init(object sender, System.EventArgs e)
		{
		
		}
	}
}
