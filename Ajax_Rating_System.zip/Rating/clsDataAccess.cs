//*****************************************************************************************************************
//Class name : clsDataAccess 
//Defination : This class is the most important class as it does all the updating,Inserting,deleting,Retrieving
//part in the database.The methods in this class is called by all the other methods in other classes.Connection
//with the database is set up here only.Added this class after analysis phase.
//any attributes in any class the only thing which is used is
//a query and nothing else. 
//Date Added : 11/23/03
//Author     : Rajesh Lal Connectrajesh@hotmail.com 
//*****************************************************************************************************************

using System;
using System.Configuration;
using System.Data; 
using System.Data.SqlClient; 

namespace Rating
{
	/// Summary description for clsDataAccess.
	
	public class clsDataAccess // Class defination
	{
		public clsDataAccess()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		 
		SqlConnection mycon = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);  
 		
		public bool openConnection() // Opens database connection with Granth in SQL SERVER
		{
			mycon.Open();
 		return true;
		}
		public void closeConnection() // Closes database connection with Granth in SQL SERVER
		{
		mycon.Close(); 
		mycon = null;
		}
		public SqlDataReader getData(string query) // Getdata from the table required(given in query)in datareader
		{
			SqlCommand sqlCommand = new SqlCommand();
			sqlCommand.CommandText= query;
			sqlCommand.Connection=mycon;
			SqlDataReader myr = sqlCommand.ExecuteReader(CommandBehavior.CloseConnection);
            return myr;
			 
		}
		public void saveData(string query) // Save data usually,inserts and updates the data in table given in query
		{
			SqlCommand sqlCommand = new SqlCommand();
			sqlCommand.CommandText= query;
			sqlCommand.Connection=mycon;
			sqlCommand.ExecuteNonQuery();
			sqlCommand.Dispose();  
			
		}
		public void saveNewData(string query) // Save data usually,inserts and updates the data in table given in query
		{
			SqlCommand sqlCommand = new SqlCommand();
			sqlCommand.CommandText= query;
			sqlCommand.Connection=mycon;
			sqlCommand.ExecuteNonQuery();
			sqlCommand.Dispose();  
			
		}
		
		public int DeleteData(string query) // Delete data in database depending on the tablename given in query.
		{
			SqlCommand sqlCommand = new SqlCommand();
			sqlCommand.CommandText= query;
			sqlCommand.Connection=mycon;
			return sqlCommand.ExecuteNonQuery();
			
		}
		public DataSet getDatabyPaging(string query) // Get data by paging using datagrid which returns the dataset in datagris
		{
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query,mycon);
			DataSet dataSet = new DataSet();
			sqlDataAdapter.Fill(dataSet,"Media");
			return dataSet;
			
		}
		public int getCheck(string query) // check a particular value to see the validity of mediaid and userid.This method is called in media and user class.
		{
			int i;
			SqlCommand sqlCommand = new SqlCommand();
			sqlCommand.CommandText= query;
			sqlCommand.Connection=mycon;
			i = Convert.ToInt32(sqlCommand.ExecuteScalar());
			return i;
		}
		public SqlDataAdapter getDataforUpdate(string query) // Get data by paging using datagrid which returns the dataset in datagris
		{
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query,mycon);
			DataSet dataSet = new DataSet();
			//sqlDataAdapter.Fill(dataSet,"NewData");
			return sqlDataAdapter;
		}
		public string getValue(string query,int j) // Get a value of limit from the database table Employees to check before issuing media.
		{
			string i ="0";
			
			SqlCommand sqlCommand = new SqlCommand();
			sqlCommand.CommandText= query;
			sqlCommand.Connection=mycon;
			SqlDataReader myReader = sqlCommand.ExecuteReader();
			
			if( myReader.Read()==true)
			{
				
				i=myReader.GetValue(j).ToString();
				
			}
			myReader.Close(); 
			return i;
		}
		
		public string getCategory(int i)
		{
			string Category ="none";
			if (i ==1)
				Category  = "General";
			else if (i ==2)
				Category = "Freshers / College graduates";
			else if (i ==3)
				Category = "Accounting/Finance";
			else if (i ==4)
				Category = "Computer Hardware";
			else if (i ==5)
				Category = "Computer Software / Internet";
			else if (i ==6)
				Category = "Electric/Electronic";
				
			else if (i ==8)
				Category = "Graphics/Multimedia";
			else if (i ==9)
				Category = "Health Care/Medical";
			else if (i ==10)
				Category = "Human Resources";
			else if (i ==11)
				Category = "IQ/EQ/Behavioral";
			else if (i ==12)
				Category = "Law/Legal";
			else if (i ==13)
				Category = "Management/Consulting";
			else if (i ==14)
				Category = "Sales/Marketing";
			else if (i ==15)
				Category = "Visa Interview";
			else if (i ==16)
				Category = "Others";
			else if (i ==18)
				Category = "Elite Members";
			return Category;
		}
	}
}
