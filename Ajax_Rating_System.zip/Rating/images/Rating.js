var xmlHttp;
var myid =0;
function createXMLHttpRequest() 
{
    if (window.ActiveXObject) 
    {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    } 
    else if (window.XMLHttpRequest) 
    {
        xmlHttp = new XMLHttpRequest();
    }
}

	var starImages = new Array("images/0star.gif",
	"images/1star.gif",
	"images/2star.gif",
	"images/3star.gif",
	"images/4star.gif",
	"images/5star.gif");
	var nullStarMessage = "images/0.gif"
	var starMap = new Array('0,0,22,20',
	'23,0,36,20',
	'37,0,50,20',
	'51,0,64,20',
	'65,0,78,20',
	'79,0,101,20');
	var starMessages = new Array("images/0.gif",
	"images/1.gif",
	"images/2.gif",
	"images/3.gif",
	"images/4.gif",
	"images/5.gif",
	"images/saved.gif");

	var savedRatings = new Array();
	var changedRatings = new Array();
	var starTwinkler = new Array();
	var msgTwinkler = new Array();
	var isRatingsBarChanged = false;
	var delayTime = 500;
	var allImages = new Array();
function preloadImages()
{
	for (i=0; i < preloadImages.length ;i++)
	{
	allImages[i] = new Image();
	allImages[i].src = preloadImages.arguments[i];
	}
}
preloadImages(starImages);
preloadImages(starMessages);

function SaveRatingAjax(id, ratingType, ratingValue)
{
	rating = ratingValue;
	var submitURL = ''
	+ 'ajaxRating.aspx?'
	+ 'id=' + id
	+ '&Rating=' + ratingValue ;
	
	myid = id;
	isRatingsBarChanged = true;
		createXMLHttpRequest();
		xmlHttp.onreadystatechange = handleStateChange;
		xmlHttp.open("GET", submitURL, true);
		xmlHttp.send(null);
}
function handleStateChange() 
{

    if(xmlHttp.readyState == 4) 
    {
        if(xmlHttp.status == 200) 
        {
  
        var myScore = document.getElementById("lblScore" + myid).innerHTML;
        var myTotal = document.getElementById("lblTotal" + myid).innerHTML;
        var myVotes = document.getElementById("lblVotes" + myid).innerHTML;
       
        
        myScore  = (parseInt(myScore,10) + parseInt(rating,10));
        myTotal = eval(parseInt(myTotal,10) + parseInt(5,10));
        myVotes = eval(parseInt(myVotes,10) + parseInt(1,10));
        
        
			document.getElementById("ltlstars" + myid).innerHTML  = '<IMG src=images/' + rating + 'star.gif>';
			document.getElementById("ltlMsg" + myid).innerHTML  = '<IMG src=images/saved.gif>';
			document.getElementById("mytrating" + myid).innerHTML = '<IMG src="images/stars' + xmlHttp.responseText + '.gif">';
			
			document.getElementById("lblScore" + myid).innerHTML = myScore;
			document.getElementById("lblTotal" + myid).innerHTML = myTotal;
			document.getElementById("lblVotes" + myid).innerHTML = myVotes;
	    }
        else
        {
        alert("Error in AJAX");
        }
    }
}
function SwapStars(id, rating)
{
	if (rating == undefined)
	{
		rating = 0;
	}
	document.images["stars." + id].src = starImages[rating];
}
function SwapStarMsg(id, rating)
{

	if (rating == undefined)
	{
		if ( changedRatings[id] ) 
		{
		
			document.images["messages." + id].src = starMessages[6];
		} 
		else 
		{
		
			document.images["messages." + id].src = nullStarMessage;
		}
	} 
	else 
	{
		document.images["messages." + id].src = starMessages[rating];
	}
}
function SaveStarsAjax(id, rating)
{
 
  
	if ((rating==1)||(rating==2)||(rating==3)||(rating==4)||(rating==5))
	{
	savedRatings[id] = rating;
	changedRatings[id] = 1;
	SaveRatingAjax(id, 'onetofive', rating);
	SwapStarMsg(id, 6);
	}
	else
	{
	alert("Rating Value out of the bound, Values can only be 1/2/3/4/5. Current rating value: " + rating);
	}
}

function StarMouseOver(id, rating)
{
//alert("StarMouseOver:" + id + ":" + rating);

	if (starTwinkler[id] != 0)
	{
	window.clearTimeout(starTwinkler[id]);
	starTwinkler[id] = 0;
	}
	if (msgTwinkler[id] != 0)
	{
	window.clearTimeout(msgTwinkler[id]);
	msgTwinkler[id] = 0;
	}
  SwapStars(id, rating);
  SwapStarMsg(id, rating); 
}
function StarMouseOut(id)
{
//alert("StarMouseOut:" + id);

	starTwinkler[id] = window.setTimeout("SwapStars('"+id+"')", delayTime);
	msgTwinkler[id] = window.setTimeout("SwapStarMsg('"+id+"')", delayTime);
}
function DisplayStarsAjax (id, rating)
{
//alert("DisplayStarsAjax:" + id);

	var starID = "stars." + id;
	starTwinkler[id] = 0;
	msgTwinkler[id] = 0;
	document.write("<map name='starmap" + id +"'>");
	var i = 0;
	for (i = 1; i < 6; i++) 
	{
	document.write("<area shape=rect " + 
	"coords='" + starMap[i] + "' " +
	"onMouseOver=\"StarMouseOver('" + id + "'," + i + ");\" " +
	"onMouseOut=\"StarMouseOut('" + id + "');\" " +
	"onClick=\"SaveStarsAjax('" + id + "'," + i + ");" +
	"\" >");
	}
	
	document.write("</map>");
	document.write("<img vspace=2 title = 'Rate Picture' src='" + starImages[rating] + "'");
	document.write(" border=0 usemap='#starmap" + id);
	document.write("' id='" + starID + "'>");
}
function DisplayMsgAjax (id, rating)
{
//alert("DisplayMsgAjax:" + id);
	var msgID = "messages." + id;
	if ( rating == undefined ) 
	{
		document.write("<img vspace=2 height=11 src='" + nullStarMessage + "'");
	}
	else 
	{
	document.write("<img vspace=2 height=11 src='" + starMessages[rating] + "'"); 
	}
	document.write("' id='" + msgID + "'>");
}

