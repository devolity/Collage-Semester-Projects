using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Text;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
using System.Configuration; 
namespace Rating
{
	/// <summary>
	/// Summary description for PhotoAll.
	/// </summary>
	public class Photo : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblTotal;
		protected System.Web.UI.WebControls.Label lblScore;
		protected System.Web.UI.WebControls.Label lblVotes;
		protected System.Web.UI.WebControls.Label lblView;
		protected System.Web.UI.WebControls.Label lblAjax;
		protected System.Web.UI.WebControls.Label lblRating;
		protected System.Web.UI.WebControls.Label lblDescription;
		protected System.Web.UI.WebControls.Label lblAddedby;
		protected System.Web.UI.WebControls.Image imgPhoto;
		protected System.Web.UI.WebControls.Literal ltlAll;
		protected System.Web.UI.WebControls.Label lblTitle;

		private void Page_Load(object sender, System.EventArgs e)
		{
			int RatedBy = 0;
			int Score = 0;
			string Title ="Title";
			int myid =1;

			if (Request.QueryString["id"]!= null)
				myid= Convert.ToInt32(Request.QueryString["id"]);
			
			// Put user code to initialize the page here
			//string query = "SELECT * FROM " + ConfigurationSettings.AppSettings["MyPhotos"];  
			string query = "SELECT * FROM " + ConfigurationSettings.AppSettings["MyPhotos"] + " WHERE ID=" + myid ;  
			
			
			clsDataAccess mydataAccess  = new clsDataAccess();
			mydataAccess.openConnection();
			SqlDataReader mydr = mydataAccess.getData(query);

			if (mydr.HasRows)
			{
				while( mydr.Read())
				{
					if (mydr.GetValue(Convert.ToInt32(ConfigurationSettings.AppSettings["ScoreByField"]))!=null)
						Score = Convert.ToInt32(mydr.GetValue(Convert.ToInt32(ConfigurationSettings.AppSettings["ScoreField"])).ToString());

					if (mydr.GetValue(Convert.ToInt32(ConfigurationSettings.AppSettings["RatedByField"]))!=null)
						RatedBy= Convert.ToInt32(mydr.GetValue(Convert.ToInt32(ConfigurationSettings.AppSettings["RatedByField"])).ToString());
			
					if (mydr.GetValue(Convert.ToInt32(ConfigurationSettings.AppSettings["TitleField"]))!=null) 
						Title  = mydr.GetValue(Convert.ToInt32(ConfigurationSettings.AppSettings["TitleField"])).ToString() ;

					myid = Convert.ToInt32(mydr.GetValue(0));

					double myScore = Convert.ToDouble(Score);
					double myRatedBy = Convert.ToDouble(RatedBy);

					double ORating = 0.0;

					if (myRatedBy>0)
						ORating = myScore/myRatedBy;
			
					string myTotalRatingString = "";

					if ((ORating <1)&&(ORating>0))
						myTotalRatingString = ".5";
					else if (ORating ==1.0)
						myTotalRatingString = "1";
					else if ((ORating >1)&&(ORating<2))
						myTotalRatingString = "1.5";
					else if (ORating ==2.0)
						myTotalRatingString = "2";
					else if ((ORating >2)&&(ORating<3))
						myTotalRatingString = "2.5";
					else if (ORating ==3.0)
						myTotalRatingString = "3";
					else if ((ORating >3)&&(ORating<4))
						myTotalRatingString = "3.5";
					else if (ORating ==4.0)
						myTotalRatingString = "4";
					else if ((ORating >4)&&(ORating<5))
						myTotalRatingString = "4.5";
					else if (ORating ==5.0)
						myTotalRatingString = "5";
					else if (ORating ==0.0)
						myTotalRatingString = "0";

					string lblRatingAjax = "<IMG src='images/stars" + myTotalRatingString + ".gif'>" ;
					
					string DisplayStarsAjax="";
					string DisplayMsgAjax="";
					
					if (Request.Cookies["RatedAjax" + myid] == null) 
					{
						DisplayStarsAjax = "<script language='Javascript'>DisplayStarsAjax(" + myid + ", rating);</script>";
						DisplayMsgAjax = "<script language='Javascript'>DisplayMsgAjax(" + myid + ");</script>";
					}
					else
					{
						HttpCookie cookieAjax = Request.Cookies["RatedAjax" + myid];
						DisplayStarsAjax = "<img src = images/" + cookieAjax.Values[0] + "star.gif>";
						DisplayMsgAjax = "<img src = images/saved.gif>";
					}
					string lblRatingAmz;
					if (Request.Cookies["RatedAmz" + myid] == null) 
					{
						lblRatingAmz = "<iframe src='Rate.aspx?id=" + myid + "' width='310' Height='28' frameborder='0' bgcolor='#F2EFE0'></iframe>";
					}
					else
					{
						HttpCookie cookieAmz = Request.Cookies["RatedAmz" + myid];
						
						StringBuilder sb1 = new StringBuilder();
						string myAmzRated =  sb1.Append( @"<TABLE CELLPADDING=0 CELLSPACING=0><TR><TD>&nbsp;&nbsp;</TD><TD><table width='300' border='0' cellspacing='0' cellpadding='1'>" )
											.Append( @"<tr><td align='left' width='64'  height='26' valign='middle'>" )
											.Append( @"" + lblRatingAjax + "</td>" )
											.Append( @"<td align='left' height='26' width='101'><img src = images/" + cookieAmz.Values[0] + "star.gif></td>" )
											.Append( @"<td align='left' width='66'>" )
											.Append( @"<img src = images/saved.gif></td></tr></table></TD></TR></TABLE>")
											.ToString();
						lblRatingAmz = myAmzRated;
					}
					


					
					StringBuilder sb = new StringBuilder();
					string myString =  sb.Append( @"<TABLE cellSpacing='1' cellPadding='1' width='500' border='1'>" )
						.Append( @"<TR><TD vAlign='middle'>&nbsp;<SPAN><FONT face='Arial'>" )
						.Append( "&nbsp;&nbsp;<STRONG>" + Title + "</STRONG>&nbsp;&nbsp;<br>")
						//.Append( @"&nbsp;&nbsp;<img src ='image.aspx?id=" + myid + "&imgColumn=3'" + " Height='200px' Width='200px' style='BORDER-RIGHT: silver 4px solid; BORDER-TOP: silver 4px solid; BORDER-LEFT: silver 4px solid; BORDER-BOTTOM: silver 4px solid' ><BR>")
						//.Append( @"&nbsp;&nbsp;<FONT face='Arial' size='2'>Added By:" + AddedBy + "<BR></TD>")
						.Append( @"</TD><TD vAlign='top'>")
						.Append( @"<STRONG><FONT face='Arial' size='2'>&nbsp;&nbsp;Rate:</FONT></STRONG>&nbsp;&nbsp;<FONT face='Arial' size='2'>Amazon	way - IFrames <BR>" + lblRatingAmz)
						.Append( @"<BR><STRONG><FONT face='Arial' size='2'>&nbsp;&nbsp;Rate:</FONT>&nbsp;</STRONG>&nbsp;<FONT face='Arial' size='2'>AJAX way&nbsp;- no refresh<BR>" )
						.Append( @"<table height='24' cellSpacing='4' cellPadding='4' width='300' bgColor='#f7f5f5' border='0'><tr><td>")
						.Append( @"<table height='24' cellSpacing='0' cellPadding='0' width='300' bgColor='#f7f5f5' border='0'><tr>")
						.Append( @"<td vAlign='middle' align='left' width='64'><DIV id='mytrating" + myid + "'>" + lblRatingAjax )
						.Append( @"</DIV></td>")
						.Append( @"<td align='left' width='101' height='26' valign='middle'>")
						.Append( @"<DIV id='ltlstars" + myid + "'>")
						.Append( @"" + DisplayStarsAjax + "")
						.Append( @"</DIV></td>")
						.Append( @"<td align='left' width='66' valign='middle'>")
						.Append( @"<DIV id='ltlMsg" + myid + "'>")
						.Append( @"" + DisplayMsgAjax + "")
						.Append( @"</DIV>")
						.Append( @"</td></tr></table></td></tr></table>")
						.Append( @"<table border = 0 width=200 cellspacing = 0><tr><td colspan=4><FONT face='Arial' size='2'><STRONG>Statistics&nbsp;&nbsp;</STRONG></FONT></td></tr>")
						.Append( @"<tr><td><FONT face='Arial' size='2' align=right>&nbsp;&nbsp;&nbsp;&nbsp;Votes:</font></td><td>")
						.Append( @"<FONT face='Arial' size='2' color=#006600><b><div id = 'lblVotes" + myid + "'>" + RatedBy.ToString())
						.Append( @"</div></b></font></td><td  colspan=2><FONT face='Arial' size='2'>&nbsp;rating(s)</FONT></td></tr>")
						.Append( @"<tr><td><FONT face='Arial' size='2' align=right>&nbsp;&nbsp;&nbsp;&nbsp;Score:</STRONG>&nbsp;</FONT></td><td align=left>")
						.Append( @"<FONT face='Arial' size='2' color=#006600><b><div id = 'lblScore" + myid + "'>" + Score.ToString())
						.Append( @"</div></b></font></td><td width=10%><b>&nbsp;/&nbsp;</b></td><td><FONT face='Arial' size='2' color=#006600><b><div id = 'lblTotal" + myid + "'>" + (RatedBy * 5).ToString())
						.Append( @"</div></b></font></td></tr></table></TD></TR></TABLE>")
						.ToString( ) ;



					ltlAll.Text = ltlAll.Text + myString;
					
					
				}
				mydr.Close();
				mydataAccess.closeConnection(); 
			}
			
 
				
			


			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}

