To compile this programme yourself, make sure;
all the source code is in the same folder
all the images are in a folder called images

type in a DOS window, javac *.java to compile all the source code
type jar -cvfm chess.jar manifest.txt *.class images/*.gif

that will put all the files in an executable jar file