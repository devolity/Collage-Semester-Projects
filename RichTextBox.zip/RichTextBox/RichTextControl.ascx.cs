namespace RichTextBox
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	public class RichTextControl : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Button btnPrint;
		protected System.Web.UI.WebControls.Label lblPrint;
		protected System.Web.UI.WebControls.TextBox HTMLText;
		protected System.Web.UI.HtmlControls.HtmlGenericControl RichTextFrame;
		protected System.Web.UI.HtmlControls.HtmlTableCell RichTextSize;
		protected System.Web.UI.WebControls.TextBox TextValue;
		protected System.Web.UI.WebControls.TextBox TxtCount;
		protected System.Web.UI.WebControls.Label lblText;	

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{
				this.RichTextFrame.Attributes["onblur"] = "fillTxtId('" + this.ClientID + "');";
			}
		}

		public string getHtml()
		{
			return HTMLText.Text.ToString();
		}

		public string getText()
		{
			return TextValue.Text.ToString();
		}

		public string RichTextChildID
		{
			get 
			{
				return this.ClientID;
			}
		}

		public string width
		{
			get
			{
				return RichTextSize.Width;
			}
			set
			{
				RichTextSize.Width = value;
			}
		}

		public string height
		{
			get
			{
				return RichTextSize.Height;
			}
			set
			{
				RichTextSize.Height = value;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
